/**
 * extension/popup/popup.js
 * Popup hanya menampilkan status dan mengirim perintah ke service worker.
 * Teks dan tindakan per keadaan ada di view.js (diuji di tests/popup-view.test.js).
 */

import { BRAKE_PRESETS, getState, effectiveLevel, siteKey, sitePausedUntil } from '../shared/state.js';
import { statusView, pageLine, MODE_DESCRIPTION, MODE_LABEL } from './view.js';

// Ikon garis sederhana (24×24), warna mengikuti teks
const ICONS = {
  check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
  shield: '<path d="M12 3l7 3v5.5c0 4.5-3 8-7 9.5-4-1.5-7-5-7-9.5V6z"/><path d="M9 12l2 2 4-4"/>',
  people: '<circle cx="9" cy="8" r="3"/><path d="M3.5 19c.5-3.5 2.8-5.5 5.5-5.5s5 2 5.5 5.5"/><circle cx="17" cy="9" r="2.5"/><path d="M16 14c2.5 0 4.2 1.8 4.5 5"/>',
  pause: '<path d="M9 5v14M15 5v14"/>',
  power: '<path d="M12 3v8"/><path d="M6.5 7a7.5 7.5 0 1 0 11 0"/>',
  moon: '<path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/>',
  camera: '<rect x="3" y="7" width="13" height="10" rx="2"/><path d="M16 11l5-3v8l-5-3"/>',
  'camera-off': '<rect x="3" y="7" width="13" height="10" rx="2"/><path d="M16 11l5-3v8l-5-3"/><path d="M3 3l18 18"/>'
};
const svg = (name) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${ICONS[name] ?? ''}</svg>`;

const $ = (id) => document.getElementById(id);
const statusEl = $('status');
const btnPrimary = $('btn-primary');
const btnReveal = $('btn-reveal');
const btnPause = $('btn-pause');
const toggle = $('toggle-enabled');
const modeDesc = $('mode-desc');
const modeSelect = $('mask-mode');
// Situs tab aktif (origin), untuk jeda per situs
const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
const activeSite = siteKey(activeTab?.url ?? '');

// Popup tidak bisa meminta izin kamera sendiri (popup tertutup saat dialog izin muncul),
// jadi hanya mengecek status izin dan mengarahkan ke halaman onboarding.
const cameraPermission = await navigator.permissions.query({ name: 'camera' });

let current = null;

function render(state) {
  current = state;
  const shown = effectiveLevel(state);
  const cameraGranted = cameraPermission.state === 'granted';
  const view = statusView(state, { shown, cameraGranted, sitePausedUntil: sitePausedUntil(state.sitePauses, activeSite) });

  statusEl.dataset.level = view.level;
  $('status-icon').innerHTML = svg(view.icon);
  $('status-title').textContent = view.title;
  $('status-sub').textContent = view.sub;

  btnPrimary.hidden = !view.primary;
  if (view.primary) {
    btnPrimary.textContent = view.primary.label;
    btnPrimary.dataset.action = view.primary.action;
  }
  btnReveal.hidden = !view.showReveal;
  renderPauseChoices(view);

  toggle.checked = state.enabled;
  const mode = state.settings?.maskMode ?? 'bawaan';
  modeSelect.value = mode;
  // Pengguna selalu melihat penjelasan tingkat bawaan; tingkat lain hanya untuk uji (Alat penelitian)
  modeDesc.textContent = mode === 'bawaan' ? MODE_DESCRIPTION.bawaan : `Mode uji: ${MODE_LABEL[mode]}. ${MODE_DESCRIPTION[mode]}`;

  // Rincian teknis hanya di Alat penelitian (keputusan D3/D4 23 Okt)
  const { stats, error, errorDetail } = state;
  $('stats').textContent = state.enabled && stats
    ? `${stats.faces} wajah terlihat · ${stats.fps} cek/detik · ${stats.delegate}` : '';
  renderPeople(state.enabled && stats?.people ? stats.people : []);
  $('error-detail').textContent = error ? `Galat terakhir: ${error}${errorDetail ? ` (${errorDetail})` : ''}` : '';
}

/**
 * Satu baris jeda (25 Nov): sebelumnya tiga kontrol (jeda situs, lamanya, jeda semua situs).
 * Pilihan situs hanya muncul bila tab punya situs dan belum dijeda; pilihan "semua situs" bila jeda global tersedia.
 */
const pauseChoice = $('pause-choice');
function renderPauseChoices(view) {
  const host = activeSite ? new URL(activeSite).hostname : '';
  const options = [];
  if (view.showSitePause && activeSite) {
    options.push(['site-hour', `Di ${host} · 1 jam`], ['site-forever', `Di ${host} · sampai saya lanjutkan`]);
  }
  if (view.showPause) options.push(['all', 'Semua situs · 10 menit']);
  $('pause-row').hidden = options.length === 0;
  const signature = options.map(([v, l]) => `${v}:${l}`).join('|');
  if (pauseChoice.dataset.signature === signature) return; // jangan mengganti pilihan yang sedang dibuka pengguna
  const previous = pauseChoice.value;
  pauseChoice.replaceChildren(...options.map(([value, label]) => new Option(label, value)));
  if (options.some(([v]) => v === previous)) pauseChoice.value = previous;
  pauseChoice.dataset.signature = signature;
}

const ROLE = {
  owner: { label: 'Pemilik', className: 'owner' },
  looking: { label: 'Menghadap layar', className: 'looking' },
  away: { label: 'Tidak menghadap', className: 'away' }
};

function renderPeople(people) {
  $('people').replaceChildren(...people.map(person => {
    const role = ROLE[person.role];
    const li = document.createElement('li');
    li.className = role.className;
    const distance = person.distanceM == null ? '' : ` · ~${String(person.distanceM).replace('.', ',')} m`;
    li.textContent = `${role.label}${distance}`;
    return li;
  }));
}

const send = (message) => chrome.runtime.sendMessage(message);

const ACTIONS = {
  enable: () => send({ type: 'set-enabled', enabled: true }),
  resume: () => send({ type: 'set-pause', on: false }),
  grant: async () => { await chrome.tabs.create({ url: chrome.runtime.getURL('onboarding/onboarding.html') }); return null; },
  'fallback-on': () => send({ type: 'set-camera-fallback', on: true }),
  'fallback-off': () => send({ type: 'set-camera-fallback', on: false }),
  'site-resume': () => send({ type: 'set-site-pause', site: activeSite, duration: null })
};

btnPrimary.addEventListener('click', async () => {
  const state = await ACTIONS[btnPrimary.dataset.action]?.();
  if (state) render(state);
});

btnPause.addEventListener('click', async () => {
  const choice = pauseChoice.value;
  if (!choice) return;
  render(await send(choice === 'all'
    ? { type: 'set-pause', on: true }
    : { type: 'set-site-pause', site: activeSite, duration: choice === 'site-hour' ? 'hour' : 'forever' }));
});


btnReveal.addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab?.id != null) chrome.tabs.sendMessage(tab.id, { type: 'dpux-reveal-all' }).catch(() => {});
  window.close();
});

toggle.addEventListener('change', async () => render(await send({ type: 'set-enabled', enabled: toggle.checked })));

modeSelect.addEventListener('change', async () => {
  render(await send({ type: 'set-settings', settings: { maskMode: modeSelect.value } }));
  refreshPageSummary();
});

// Popup ikut berubah saat status di storage berubah (mis. ada orang datang selagi popup terbuka)
chrome.storage.onChanged.addListener(async (_changes, area) => {
  if (area === 'local') render(await getState());
});

// C-9: pengingat menyematkan ikon, karena badge adalah satu-satunya tanda status saat halaman tidak disamarkan
chrome.action.getUserSettings?.().then(({ isOnToolbar }) => { $('pin-hint').hidden = isOnToolbar; }).catch(() => {});

// ------------------------------------------------------------------ ringkasan halaman

async function refreshPageSummary() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const s = tab?.id == null ? null
    : await chrome.tabs.sendMessage(tab.id, { type: 'scan-summary' }, { frameId: 0 }).catch(() => null);
  $('page-summary').textContent = pageLine(s, { maskMode: current?.settings?.maskMode ?? 'bawaan', url: tab?.url });
  $('page-tech').textContent = s
    ? `Halaman: ${s.byLevel.selalu} SELALU + ${s.byLevel.ketat} KETAT + ${s.byLevel.pilihan ?? 0} PILIHAN`
      + (s.build ? ` · kode tab ${new Date(s.build).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}` : '')
    : '';
}
setInterval(refreshPageSummary, 2000);

// ------------------------------------------------------------------ alat penelitian (T0)

// Tersembunyi dari peserta (25 Nov). Peneliti: klik label "Purwarupa" 5 kali dalam 3 detik untuk
// menampilkan/menyembunyikan; pilihan diingat di browser ini saja (paket baru = tersembunyi lagi).
const RESEARCH_KEY = 'dpuxResearchUnlocked';
const researchEl = $('research');
chrome.storage.local.get(RESEARCH_KEY).then(r => { researchEl.hidden = !r?.[RESEARCH_KEY]; }).catch(() => {});
let tagClicks = [];
$('tag').addEventListener('click', () => {
  const now = Date.now();
  tagClicks = [...tagClicks.filter(t => now - t < 3000), now];
  if (tagClicks.length < 5) return;
  tagClicks = [];
  researchEl.hidden = !researchEl.hidden;
  chrome.storage.local.set({ [RESEARCH_KEY]: !researchEl.hidden }).catch(() => {});
});

const brakeOn = $('brake-on');
const brakeOff = $('brake-off');
const simulate = $('simulate');
const cameraMode = $('camera-mode');
const logSummary = $('log-summary');
const btnLogDownload = $('btn-log-download');
const btnLogClear = $('btn-log-clear');

const presetOf = (presets, ms) => Object.keys(presets).find(k => presets[k] === ms) ?? 'default';

function renderSettings({ settings }) {
  cameraMode.value = settings?.cameraMode ?? 'kebutuhan';
  brakeOn.value = presetOf(BRAKE_PRESETS.on, settings?.threatOnMs);
  brakeOff.value = presetOf(BRAKE_PRESETS.off, settings?.threatOffMs);
  simulate.value = settings?.simulateLevel ?? '';
}

async function saveSettings(settings) {
  const state = await send({ type: 'set-settings', settings });
  render(state);
  renderSettings(state);
}

cameraMode.addEventListener('change', () => saveSettings({ cameraMode: cameraMode.value }));
simulate.addEventListener('change', () => saveSettings({ simulateLevel: simulate.value || null }));
const saveBrake = () => saveSettings({ threatOnMs: BRAKE_PRESETS.on[brakeOn.value], threatOffMs: BRAKE_PRESETS.off[brakeOff.value] });
brakeOn.addEventListener('change', saveBrake);
brakeOff.addEventListener('change', saveBrake);

// Log disimpan di offscreen document; bila mesin visi mati, tidak ada yang menjawab
async function refreshLogSummary() {
  const s = await send({ type: 'vision-log-summary' }).catch(() => null);
  logSummary.textContent = s
    ? `Log: ${s.frames} frame · ${(s.durationMs / 60000).toFixed(1).replace('.', ',')} menit · ${s.levelChanges} perubahan status`
    : 'Log: mesin visi belum berjalan, belum ada yang bisa diunduh';
  // Tombol hanya aktif bila ada log, supaya tidak terlihat "rusak" saat diklik
  btnLogDownload.disabled = !s || s.frames === 0;
  btnLogClear.disabled = !s || s.frames === 0;
}

btnLogDownload.addEventListener('click', async () => {
  const data = await send({ type: 'vision-get-log' }).catch(() => null);
  if (!data) return refreshLogSummary();
  const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([JSON.stringify(data)], { type: 'application/json' }));
  a.download = `dpux-log-${stamp}.json`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
});

btnLogClear.addEventListener('click', async () => {
  await send({ type: 'vision-clear-log' }).catch(() => null);
  refreshLogSummary();
});

$('research').addEventListener('toggle', refreshLogSummary);
setInterval(refreshLogSummary, 2000);

// Daftar temuan (nilai disensor) + aturan yang memicunya, untuk diagnosis di situs nyata
$('scan-debug').addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab?.id != null) chrome.tabs.sendMessage(tab.id, { type: 'scan-debug' }, { frameId: 0 }).catch(() => {});
});

$('open-model-check').addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('dev/model-check.html') });
});

// ------------------------------------------------------------------ mulai

// Galat apa pun saat memuat harus terlihat, bukan diam di "Memuat…" (temuan uji 21 Okt)
try {
  const initialState = await send({ type: 'get-state' });
  if (!initialState) throw new Error('service worker tidak mengirim status');
  render(initialState);
  renderSettings(initialState);
  refreshPageSummary();
  refreshLogSummary();
} catch (err) {
  $('status-title').textContent = 'Popup gagal memuat status';
  $('status-sub').textContent = `${err?.message ?? err}. Tutup lalu buka popup lagi; bila berulang, muat ulang extension.`;
}
