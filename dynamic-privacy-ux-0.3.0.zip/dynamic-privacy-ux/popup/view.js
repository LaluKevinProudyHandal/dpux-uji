/**
 * extension/popup/view.js
 * Apa yang ditampilkan popup untuk tiap keadaan: judul, penjelas, ikon, dan satu tindakan utama.
 * Fungsi murni (tanpa chrome.*) agar bisa diuji di Node.
 *
 * Keputusan desain 23 Okt (docs/usulan-desain-popup.md bagian 7):
 * - Teks tidak menjanjikan lebih dari kemampuan sistem: "tidak terdeteksi", bukan "hanya Anda yang melihat";
 *   "menghadap layar" (sistem membaca arah kepala, bukan arah mata).
 * - Tombol utama berwarna hanya bila memang ada tindakan yang dibutuhkan; "Jeda 10 menit" hanya tombol sekunder.
 * - Sapaan "Anda", sama dengan tooltip penutup (taxonomy.js).
 */

import { LEVEL, SITE_PAUSE, pilihanFor } from '../shared/state.js';

// Satu kontrol bertingkat (keputusan 28 Okt): tiap tingkat mencakup tingkat di bawahnya
export const MODE_LABEL = Object.freeze({ bawaan: 'Standar', ketat: 'Tinggi', maksimal: 'Maksimal' });
export const MODE_DESCRIPTION = Object.freeze({
  bawaan: 'Disamarkan saat ada yang melihat: data keuangan, identitas (NIK, KK, NPWP), kesehatan, kata sandi, dan kode OTP, yaitu data pribadi yang menurut UU PDP paling berisiko.',
  ketat: 'Standar, ditambah nomor HP, email, alamat IP, nilai, agama, BPJS, dan paspor/SIM.',
  maksimal: 'Tinggi, ditambah nama lengkap, alamat, dan tanggal lahir (bila ada labelnya, mis. "Nama:").'
});

const ERROR_VIEW = {
  camera: { title: 'Kamera tidak tersedia', sub: 'Perlindungan otomatis berhenti. Dicoba lagi tiap 30 detik.' },
  covered: { title: 'Kamera tertutup', sub: 'Buka penutup lensa agar perlindungan bekerja lagi.' },
  model: { title: 'Mesin deteksi gagal', sub: 'Muat ulang extension di chrome://extensions.' },
  internal: { title: 'Mesin deteksi gagal', sub: 'Muat ulang extension di chrome://extensions.' }
};

const clock = (ms) => new Date(ms).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });

/** Jumlah orang selain pemilik dari statistik mesin visi: { looking, others }. */
function countPeople(stats) {
  const people = stats?.people ?? [];
  return {
    looking: people.filter(p => p.role === 'looking').length,
    others: people.filter(p => p.role !== 'owner').length
  };
}

/**
 * @param {object} state status tersimpan (shared/state.js) + level efektif
 * @param {{ shown: string, cameraGranted: boolean, now?: number }} ctx
 * @returns {{ level: string, icon: string, title: string, sub: string,
 *             primary: null | { label: string, action: string }, showPause: boolean, showReveal: boolean }}
 */
export function statusView(state, { shown, cameraGranted, sitePausedUntil = 0, now = Date.now() }) {
  const { enabled, error, cameraFallback, pausedUntil, stats, settings } = state;
  const simulated = Boolean(enabled && settings?.simulateLevel);
  const { looking, others } = countPeople(stats);
  let view;

  if (!enabled) {
    view = { level: 'off', icon: 'power', title: 'Perlindungan mati', sub: 'Data tidak disamarkan.',
      primary: { label: 'Nyalakan perlindungan', action: 'enable' } };
  } else if (shown === LEVEL.PAUSED) {
    view = { level: 'paused', icon: 'pause', title: `Dijeda sampai ${clock(pausedUntil)}`, sub: 'Data tidak disamarkan.',
      primary: { label: 'Lanjutkan sekarang', action: 'resume' } };
  } else if (sitePausedUntil > now) {
    // Jeda per situs (keputusan 28 Okt): hanya situs ini; situs lain tetap terlindungi
    view = { level: 'paused', icon: 'pause', title: 'Dijeda di situs ini',
      sub: sitePausedUntil >= SITE_PAUSE.forever ? 'Data di situs ini tidak disamarkan sampai Anda melanjutkan.'
        : `Data di situs ini tidak disamarkan sampai ${clock(sitePausedUntil)}.`,
      primary: { label: 'Lanjutkan di situs ini', action: 'site-resume' } };
  } else if (!cameraGranted || error === 'permission') {
    view = { level: 'unknown', icon: 'camera-off', title: 'Izin kamera dibutuhkan',
      sub: 'Perlindungan otomatis belum bisa bekerja.', primary: { label: 'Izinkan kamera', action: 'grant' } };
  } else if (error && !simulated) {
    const e = ERROR_VIEW[error] ?? ERROR_VIEW.internal;
    view = cameraFallback
      ? { level: 'fallback', icon: 'shield', title: 'Data disamarkan',
        sub: 'Kamera tidak tersedia; Anda memilih tetap menyamarkan.', primary: { label: 'Berhenti menyamarkan', action: 'fallback-off' } }
      : { level: 'unknown', icon: 'camera-off', title: e.title, sub: e.sub,
        primary: { label: 'Samarkan terus sampai kamera kembali', action: 'fallback-on' } };
  } else if (shown === LEVEL.THREAT) {
    view = { level: 'threat', icon: 'shield', title: 'Data disamarkan',
      sub: simulated ? 'Simulasi: ada orang menghadap layar.'
        : looking > 1 ? `${looking} orang menghadap layar.` : 'Ada orang menghadap layar.' };
  } else if (shown === LEVEL.WARMING) {
    view = { level: 'warming', icon: 'shield', title: 'Menyiapkan kamera', sub: 'Data disamarkan dulu.' };
  } else if (shown === LEVEL.AWARE) {
    view = { level: 'aware', icon: 'people', title: 'Ada orang di sekitar',
      sub: others > 1 ? `${others} orang, belum menghadap layar.` : 'Belum menghadap layar.' };
  } else if (shown === LEVEL.SAFE) {
    view = { level: 'safe', icon: 'check', title: 'Aman', sub: 'Tidak ada orang lain terdeteksi.' };
  } else if (shown === LEVEL.STANDBY) {
    view = { level: 'standby', icon: 'moon', title: 'Siaga', sub: 'Tidak ada data sensitif di tab ini. Kamera istirahat.' };
  } else {
    view = { level: 'unknown', icon: 'camera', title: 'Menyalakan kamera', sub: 'Sebentar…' };
  }

  view.primary ??= null;
  view.showPause = Boolean(enabled && shown !== LEVEL.PAUSED);
  view.showSitePause = Boolean(enabled && shown !== LEVEL.PAUSED && !(sitePausedUntil > now));
  view.showReveal = view.level === 'threat' || view.level === 'warming' || view.level === 'fallback';
  return view;
}

/** Ringkasan halaman untuk pengguna: jumlah data sensitif pada mode terpilih. */
export function pageLine(summary, { maskMode, url }) {
  const pilihan = pilihanFor(maskMode);
  if (!summary) {
    return /^https?:/.test(url ?? '')
      ? 'Halaman ini sedang disiapkan. Bila tidak berubah, muat ulang halaman (F5).'
      : 'Halaman ini tidak bisa dilindungi (mis. halaman Chrome atau PDF).';
  }
  const n = summary.byLevel.selalu + (maskMode !== 'bawaan' ? summary.byLevel.ketat : 0)
    + pilihan.reduce((k, c) => k + (summary.byCategory?.[c] ?? 0), 0);
  return n === 0 ? 'Tidak ada data sensitif di halaman ini.' : `${n} data sensitif ditemukan di halaman ini.`;
}
