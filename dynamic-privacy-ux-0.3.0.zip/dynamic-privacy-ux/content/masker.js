/**
 * extension/content/masker.js
 * Penyamar (T3): menutup data sensitif dengan lapisan di atas halaman, tanpa mengubah DOM situs.
 * Mengikuti docs/spesifikasi-interaksi-ux.md bagian C★:
 * - C-3: penutup berisi titik, jumlah tetap; tanpa nama kategori; warna latar mengikuti elemen asli.
 * - C-4: kartu & rekening memperlihatkan 4 digit terakhir; lainnya tertutup penuh.
 * - C-6: klik penutup → elemen terbuka, tertutup lagi setelah revealTimeoutMs bila pengamat masih ada;
 *        tooltip alasan + pasal; kolom isian: klik pertama membuka penutup, klik kedua masuk ke kolom.
 * - P8: lapisan aria-hidden, sehingga pembaca layar pemilik tetap membaca isi asli.
 */

import { TAXONOMY, isActiveInMode } from '../../sensitive-core/index.js';
import { OWN_ATTR } from './scanner.js';

const DOTS = '••••••';
const LAST4 = new Set(['K02', 'K03']); // C-4
const TRANSPARENT = /^(transparent|rgba\(\s*0,\s*0,\s*0,\s*0\s*\))$/;

const CSS_TEXT = `
:host { all: initial; }
.layer { position: absolute; top: 0; left: 0; width: 0; height: 0; pointer-events: none; z-index: 2147483647; }
.cover {
  position: absolute; box-sizing: border-box; pointer-events: auto; cursor: pointer; overflow: hidden;
  display: flex; align-items: center; white-space: nowrap; border-radius: 3px;
  letter-spacing: 0.08em; opacity: 0; transition: opacity 120ms ease-out;
}
.cover.on { opacity: 1; }
.cover.pinned { position: fixed; }
.cover.top { pointer-events: none; cursor: default; }
.cover.blur { -webkit-backdrop-filter: blur(9px); backdrop-filter: blur(9px); background: transparent !important; }
@media (prefers-reduced-motion: reduce) { .cover { transition: none; } }
`;

/** Warna latar efektif sebuah elemen (naik ke leluhur sampai menemukan yang tidak transparan). */
function effectiveBackground(el, cache) {
  const path = [];
  let color = null;
  for (let cur = el; cur && cur.nodeType === Node.ELEMENT_NODE; cur = cur.parentElement ?? cur.getRootNode?.().host) {
    if (cache.has(cur)) { color = cache.get(cur); break; }
    path.push(cur);
    const cs = getComputedStyle(cur);
    const bg = cs.backgroundColor;
    // Latar tembus pandang (kotak kutipan WhatsApp, uji 23 Okt) dipadukan dengan latar di bawahnya;
    // tanpa ini penutup ikut tembus pandang dan data di bawahnya terbaca
    if (bg && !TRANSPARENT.test(bg) && alphaOf(bg) < 0.99) {
      const below = effectiveBackground(cur.parentElement ?? cur.getRootNode?.().host, cache);
      color = `color-mix(in srgb, ${bg.replace(/rgba\(([^,]+),([^,]+),([^,]+),[^)]+\)/, 'rgb($1,$2,$3)')} ${Math.round(alphaOf(bg) * 100)}%, ${below})`;
      break;
    }
    if (bg && !TRANSPARENT.test(bg)) { color = bg; break; }
    // Latar gradasi/gambar tidak punya backgroundColor; tanpa ini penutup mengambil warna halaman di bawahnya
    // (uji bank tiruan 22 Okt: kotak putih di atas kartu saldo biru). Warna pertama gradasi cukup mendekati.
    if (cs.backgroundImage && cs.backgroundImage !== 'none') {
      const stop = cs.backgroundImage.match(/rgba?\([^)]*\)/)?.[0];
      color = stop && !TRANSPARENT.test(stop) ? stop : IMAGE_BACKGROUND;
      break;
    }
  }
  color ??= 'rgb(255, 255, 255)';
  for (const p of path) cache.set(p, color);
  return color;
}

/** Latar berupa gambar tanpa warna yang bisa dibaca: pilih latar gelap/terang yang kontras dengan teksnya. */
const IMAGE_BACKGROUND = 'image';
function solidBackground(bg, textColor) {
  if (bg !== IMAGE_BACKGROUND) return bg;
  const [r, g, b] = (textColor.match(/\d+(\.\d+)?/g) ?? [0, 0, 0]).map(Number);
  return (0.299 * r + 0.587 * g + 0.114 * b) > 140 ? 'rgb(30, 41, 59)' : 'rgb(241, 245, 249)';
}

/** Apakah elemen berada di dalam leluhur fixed/sticky (header menempel): penutupnya harus ikut layar. */
function inPinnedAncestor(el, cache) {
  const path = [];
  let pinned = false;
  for (let cur = el; cur && cur.nodeType === Node.ELEMENT_NODE; cur = cur.parentElement ?? cur.getRootNode?.().host) {
    if (cache.has(cur)) { pinned = cache.get(cur); break; }
    path.push(cur);
    const pos = getComputedStyle(cur).position;
    if (pos === 'fixed' || pos === 'sticky') { pinned = true; break; }
  }
  for (const p of path) cache.set(p, pinned);
  return pinned;
}

/**
 * Leluhur yang memotong isinya (overflow selain visible), mis. kotak daftar mutasi yang bisa digulir.
 * Penutup dipotong mengikuti batas leluhur ini; data yang tergulir keluar kotak tidak diberi penutup.
 * Temuan uji Chrome 18 Okt: tanpa ini penutup baris tersembunyi tampil di luar kotak.
 */
function clippingAncestors(el, cache) {
  if (cache.has(el)) return cache.get(el);
  const list = [];
  for (let cur = el.parentElement ?? el.getRootNode?.().host; cur && cur !== el.ownerDocument.documentElement;
    cur = cur.parentElement ?? cur.getRootNode?.().host) {
    const cs = getComputedStyle(cur);
    if (cs.overflowX !== 'visible' || cs.overflowY !== 'visible') list.push(cur);
  }
  cache.set(el, list);
  return list;
}

// Bantalan penutup ditambahkan SEBELUM dipotong agar tidak melewati batas kotak scroll
const PAD = 1;

function clipRect(rect, ancestors) {
  let left = rect.left - PAD, top = rect.top - PAD, right = rect.right + PAD, bottom = rect.bottom + PAD;
  for (const a of ancestors) {
    // Kotak padding (tanpa border dan scrollbar): area tempat isi benar-benar terlihat
    const r = a.getBoundingClientRect();
    const l = r.left + a.clientLeft, t = r.top + a.clientTop;
    left = Math.max(left, l); top = Math.max(top, t);
    right = Math.min(right, l + a.clientWidth); bottom = Math.min(bottom, t + a.clientHeight);
    if (right <= left || bottom <= top) return null;
  }
  return { left, top, right, bottom, width: right - left, height: bottom - top };
}

// Seberapa sering status "tertimpa elemen lain" dihitung ulang per elemen (elementsFromPoint cukup mahal)
const OCCLUSION_TTL_MS = 300;
const VISIBLE = 0, DIMMED = 1, HIDDEN = 2;

function alphaOf(color) {
  if (!color || TRANSPARENT.test(color)) return 0;
  // Format modern: "color(srgb 1 1 1 / 0.5)", "oklch(… / 40%)" (uji Shopee 3 Nov: penutup tembus pandang)
  const slash = color.match(/\/\s*([\d.]+)(%?)\s*\)\s*$/);
  if (slash) return parseFloat(slash[1]) / (slash[2] ? 100 : 1);
  const m = color.match(/rgba?\(([^)]+)\)/);
  if (!m) return 1;
  const parts = m[1].split(/[\s,/]+/).filter(Boolean);
  return parts.length >= 4 ? parseFloat(parts[3]) : 1;
}

/** Opasitas kumulatif elemen dan leluhurnya. */
function cumulativeOpacity(el) {
  let o = 1;
  for (let cur = el; cur && cur.nodeType === Node.ELEMENT_NODE; cur = cur.parentElement) o *= parseFloat(getComputedStyle(cur).opacity) || 0;
  return o;
}

/** Elemen yang menutupi sepenuhnya apa pun di belakangnya (latar padat, tidak tembus pandang). */
function isOpaque(el) {
  return alphaOf(getComputedStyle(el).backgroundColor) >= 0.99 && cumulativeOpacity(el) >= 0.99;
}

/** Elemen tanpa latar (pembungkus transparan) tidak meredupkan apa pun. */
function isClear(el) {
  const cs = getComputedStyle(el);
  return alphaOf(cs.backgroundColor) === 0 && cs.backdropFilter === 'none' && cs.filter === 'none';
}

/**
 * Penutup dibuat sedikit lebih gelap/terang dari latar agar terbaca sebagai satu blok.
 * Temuan uji SIMASTER 19 Okt: latar yang persis sama membuat titik tampak "melayang acak"
 * di dalam ruang kosong selebar data asli.
 */
function coverBackground(bg, textColor) {
  const tint = `color-mix(in srgb, ${bg} 90%, ${textColor})`;
  // Alas padat di bawah warna penutup: warna apa pun yang lolos sebagai tembus pandang tidak bisa
  // memperlihatkan data di bawahnya (uji Shopee 3 Nov: angka kartu samar terlihat di balik penutup)
  const [r, g, b] = (textColor.match(/\d+(\.\d+)?/g) ?? [0, 0, 0]).map(Number);
  const base = (0.299 * r + 0.587 * g + 0.114 * b) > 140 ? 'rgb(30, 41, 59)' : 'rgb(255, 255, 255)';
  return `linear-gradient(${tint}, ${tint}), ${base}`;
}

function coverText(category, original) {
  if (LAST4.has(category)) {
    const digits = original.replace(/\D/g, '');
    if (digits.length >= 8) return `•••• ${digits.slice(-4)}`;
  }
  return DOTS;
}

/**
 * @param {Document} doc
 * @param {ReturnType<import('./scanner.js').createScanner>} scanner
 * @param {{ revealTimeoutMs?: number }} [options]
 */
export function createMasker(doc, scanner, { revealTimeoutMs = 10000, shadowMode = 'closed' } = {}) {
  let host = null;
  let layer = null;
  let active = false;
  let mode = 'bawaan';
  let pilihan = []; // kategori PILIHAN yang dinyalakan pengguna
  let style = 'opak';
  let frame = null;
  let revealAllUntil = 0;
  const revealedText = new WeakMap(); // Text → Map<start, expiresAt>
  const revealedField = new WeakMap(); // Element → expiresAt
  const pool = [];
  let bgCache = new WeakMap();
  let pinCache = new WeakMap();
  let clipCache = new WeakMap();
  let occlusionCache = new WeakMap();
  const metrics = { lastActivatedAt: null, firstPaintMs: null, covers: 0 };

  function ensureHost() {
    if (host?.isConnected) return;
    host = doc.createElement('div');
    host.setAttribute(OWN_ATTR, 'mask');
    host.setAttribute('aria-hidden', 'true');
    // Ditambatkan ke dokumen (bukan layar) agar penutup ikut tergulir bersama halaman di compositor.
    // Temuan uji Chrome 18 Okt: penutup position:fixed tertinggal satu frame saat scroll cepat → data sempat terlihat.
    host.style.cssText = 'position:absolute;top:0;left:0;width:0;height:0;margin:0;padding:0;border:0;z-index:2147483647;';
    const root = host.attachShadow({ mode: shadowMode }); // 'open' hanya untuk uji otomatis
    const styleEl = doc.createElement('style');
    styleEl.textContent = CSS_TEXT;
    layer = doc.createElement('div');
    layer.className = 'layer';
    root.append(styleEl, layer);
    (doc.documentElement ?? doc.body).appendChild(host);
  }

  /**
   * Lapisan kedua di TOP LAYER browser, untuk data di dalam popover/dialog modal/layar penuh situs.
   * Uji Halodoc 4 Nov: jendela kode OTP adalah popover (top layer), yang selalu tampil di atas z-index berapa pun,
   * sehingga penutup biasa tertimbun dan kode terlihat. Lapisan ini sendiri popover "manual" (tidak menutup popover
   * situs) dan dinaikkan ulang setiap kali situs membuka elemen top layer baru, agar selalu paling atas.
   * Penutupnya tidak bisa diklik: klik di luar popover situs bisa menutup jendela itu (light dismiss);
   * membuka sementara tetap lewat pintasan "tampilkan semua".
   */
  let topHost = null;
  let topLayer = null;
  let raisedOver = new WeakSet();
  const TOP_SELECTOR = ':popover-open, :modal, :fullscreen';

  function topLayerOf(el) {
    try { return el.closest(TOP_SELECTOR); } catch { return null; } // selektor tidak dikenal di browser lama
  }

  function ensureTopHost() {
    if (!topHost?.isConnected) {
      topHost = doc.createElement('div');
      topHost.setAttribute(OWN_ATTR, 'mask');
      topHost.setAttribute('aria-hidden', 'true');
      topHost.setAttribute('popover', 'manual');
      topHost.style.cssText = 'position:fixed;inset:0 auto auto 0;width:0;height:0;margin:0;padding:0;border:0;'
        + 'overflow:visible;background:transparent;';
      const root = topHost.attachShadow({ mode: shadowMode });
      const styleEl = doc.createElement('style');
      styleEl.textContent = CSS_TEXT;
      topLayer = doc.createElement('div');
      topLayer.className = 'layer';
      root.append(styleEl, topLayer);
      (doc.documentElement ?? doc.body).appendChild(topHost);
      raisedOver = new WeakSet();
    }
    let opened = [];
    try { opened = [...doc.querySelectorAll(TOP_SELECTOR)].filter(e => e !== topHost); } catch { /* lama */ }
    const showing = topHost.matches(':popover-open');
    if (!showing || opened.some(e => !raisedOver.has(e))) {
      try {
        if (showing) topHost.hidePopover();
        topHost.showPopover();
      } catch { /* Popover API tidak tersedia */ }
      opened.forEach(e => raisedOver.add(e));
    }
  }

  function hideTopHost() {
    try { if (topHost?.matches(':popover-open')) topHost.hidePopover(); } catch { /* abaikan */ }
  }

  function isRevealed(target, now) {
    if (now < revealAllUntil) return true;
    if (target.field) return (revealedField.get(target.field) ?? 0) > now;
    return (revealedText.get(target.node)?.get(target.start) ?? 0) > now;
  }

  function reveal(target) {
    const until = performance.now() + revealTimeoutMs;
    if (target.field) revealedField.set(target.field, until);
    else {
      if (!revealedText.has(target.node)) revealedText.set(target.node, new Map());
      revealedText.get(target.node).set(target.start, until);
    }
  }

  function coverAt(i) {
    let el = pool[i];
    if (!el) {
      el = doc.createElement('div');
      el.className = 'cover';
      el.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (el._target) reveal(el._target);
      });
      pool[i] = el;
    }
    if (!el.isConnected) layer.appendChild(el);
    return el;
  }

  /** Teks di dalam kotak ketik (contenteditable) yang sedang difokus: terbuka selama diketik (keputusan A, 22 Okt). */
  function inFocusedEditor(node) {
    const editor = node.parentElement?.closest('[contenteditable=""], [contenteditable="true"], [contenteditable="plaintext-only"]');
    return Boolean(editor) && editor.contains(doc.activeElement);
  }
  function isLargeOverlay(e) {
    const r = e.getBoundingClientRect();
    return r.width * r.height >= 0.5 * window.innerWidth * window.innerHeight;
  }

  /**
   * contains() yang menembus batas shadow root. elementsFromPoint di dokumen hanya mengembalikan pembungkus
   * shadow root, bukan isinya (uji X 28 Okt); pembungkus itu tidak boleh dianggap elemen yang menimpa data.
   */
  function composedContains(outer, inner) {
    for (let n = inner; n; n = n.parentNode ?? n.host) if (n === outer) return true;
    return false;
  }

  /** Keadaan satu titik: VISIBLE, DIMMED (di bawah lapisan tembus pandang), atau HIDDEN (di bawah elemen padat). */
  function occlusionAt(el, x, y) {
    let state = VISIBLE;
    for (const e of doc.elementsFromPoint(x, y)) {
      if (e === host) continue;
      if (e === el || composedContains(el, e) || composedContains(e, el)) return state; // sampai di data itu sendiri
      if (isOpaque(e)) return HIDDEN;
      // Uji WhatsApp 23 Okt: sorotan baris terpilih/kotak kutipan yang tembus pandang membuat penutup menjadi blur
      // yang masih terbaca. Blur hanya untuk lapisan yang menutupi sebagian besar layar (latar gelap pop-up).
      if (!isClear(e) && isLargeOverlay(e)) state = DIMMED;
    }
    return state;
  }

  /**
   * Apakah data tertimpa elemen lain (temuan uji SIMASTER 19 Okt, jendela pop-up):
   * - VISIBLE: tidak tertimpa → penutup biasa;
   * - DIMMED: tertimpa lapisan tembus pandang (latar gelap pop-up) → data masih samar terbaca,
   *   jadi tetap disamarkan, tetapi dengan blur agar ikut redup bersama halaman;
   * - HIDDEN: tertimpa elemen padat (isi pop-up) → tidak terlihat, tidak perlu penutup
   *   (blur di sini justru akan mengaburkan isi pop-up).
   */
  function occlusionOf(el, rect, now) {
    // Hitung ulang bila posisinya bergeser (scroll): hasil lama bisa membuat data yang baru keluar
    // dari bawah header sempat tidak tertutup
    const hit = occlusionCache.get(el);
    if (hit && now - hit.at < OCCLUSION_TTL_MS && hit.left === rect.left && hit.top === rect.top) return hit.value;
    // Beberapa titik, bukan hanya tengah: data yang setengah tergulir di bawah header menempel
    // masih terlihat sebagian dan harus tetap ditutup (temuan uji Google Account 21 Okt).
    const inset = Math.min(2, rect.width / 4, rect.height / 4);
    const xs = [rect.left + inset, rect.left + rect.width / 2, rect.right - inset];
    const ys = [rect.top + inset, rect.top + rect.height / 2, rect.bottom - inset];
    let value = HIDDEN;
    let sampled = 0;
    for (const y of ys) {
      for (const x of xs) {
        if (x < 0 || y < 0 || x >= window.innerWidth || y >= window.innerHeight) continue;
        sampled++;
        const state = occlusionAt(el, x, y);
        if (state < value) value = state;
        if (value === VISIBLE) break;
      }
      if (value === VISIBLE) break;
    }
    if (!sampled) value = VISIBLE; // di luar layar (dipasang lebih dulu): anggap terlihat
    occlusionCache.set(el, { at: now, value, left: rect.left, top: rect.top });
    return value;
  }

  /** Daftar area yang harus ditutup pada frame ini. */
  function collectTargets(now) {
    const targets = [];
    const vh = window.innerHeight, vw = window.innerWidth;
    // Penutup juga dipasang sedikit di luar layar (±1 layar) agar sudah ada sebelum tergulir masuk
    const visible = (r) => r.width > 0 && r.height > 0 && r.bottom > -vh && r.top < 2 * vh && r.right > 0 && r.left < vw;

    for (const [node, list] of scanner.textFindings) {
      if (!node.isConnected) continue;
      for (const f of list) {
        if (!isActiveInMode(f.category, mode, pilihan)) continue;
        const target = { node, start: f.start, category: f.category };
        if (isRevealed(target, now)) continue;
        if (inFocusedEditor(node)) continue;
        const end = Math.min(f.end, node.nodeValue.length);
        if (f.start >= end) continue;
        const range = doc.createRange();
        range.setStart(node, f.start);
        range.setEnd(node, end);
        const clips = clippingAncestors(node.parentElement, clipCache);
        const rects = [...range.getClientRects()].map(r => clipRect(r, clips)).filter(r => r && visible(r));
        rects.forEach((rect, k) => {
          const occlusion = occlusionOf(node.parentElement, rect, now);
          if (occlusion === HIDDEN) return;
          targets.push({
            rect, target, el: node.parentElement, occlusion,
            text: k === 0 ? (f.partial ? DOTS : coverText(f.category, node.nodeValue.slice(f.start, end))) : ''
          });
        });
      }
    }
    for (const [field, list] of scanner.fieldFindings) {
      if (!field.isConnected) continue;
      // Kolom kosong tidak menyembunyikan apa pun; penutupnya hanya menghalangi pengguna yang mau mengisi
      // (uji Shopee 22 Okt: kolom kode OTP kosong tertutup sebelum sempat diketik)
      if (!String(field.value ?? '').trim()) continue;
      // Kolom password sudah disamarkan browser; penutup baru berguna bila isinya ditampilkan (tombol "mata")
      if (field.type === 'password') continue;
      // Keputusan Kevin 22 Okt (pilihan A): kolom yang sedang diketik tetap terbuka selama fokus,
      // lalu tertutup lagi begitu pengguna pindah. Mengetik kode OTP tanpa melihat rawan salah ketik.
      if (field.matches?.(':focus')) continue;
      const f = list.find(x => isActiveInMode(x.category, mode, pilihan));
      if (!f) continue;
      const target = { field, category: f.category };
      if (isRevealed(target, now)) continue;
      const rect = clipRect(field.getBoundingClientRect(), clippingAncestors(field, clipCache));
      if (!rect || !visible(rect)) continue;
      const occlusion = occlusionOf(field, rect, now);
      if (occlusion === HIDDEN) continue;
      targets.push({ rect, target, el: field, occlusion, text: coverText(f.category, field.value ?? '') });
    }
    return targets;
  }

  function render() {
    frame = null;
    if (!active) return;
    ensureHost();
    const now = performance.now();
    const targets = collectTargets(now);
    let usedTop = false;
    targets.forEach((t, i) => {
      const el = coverAt(i);
      const cs = getComputedStyle(t.el);
      el._target = t.target;
      const inTop = Boolean(topLayerOf(t.el));
      if (inTop) {
        if (!usedTop) { ensureTopHost(); usedTop = true; }
        if (el.parentNode !== topLayer) topLayer.appendChild(el);
      } else if (el.parentNode !== layer) layer.appendChild(el);
      el.classList.toggle('top', inTop);
      // Lapisan top layer berposisi tetap terhadap layar, jadi koordinatnya koordinat layar
      const pinned = inTop || inPinnedAncestor(t.el, pinCache);
      const ox = pinned ? 0 : window.scrollX;
      const oy = pinned ? 0 : window.scrollY;
      el.classList.toggle('pinned', pinned);
      el.style.left = `${t.rect.left + ox}px`;
      el.style.top = `${t.rect.top + oy}px`;
      el.style.width = `${t.rect.width}px`;
      el.style.height = `${t.rect.height}px`;
      el.style.font = cs.font;
      el.style.color = cs.color;
      el.style.background = coverBackground(solidBackground(effectiveBackground(t.el, bgCache), cs.color), cs.color);
      el.style.paddingLeft = t.el.matches?.('input, textarea') ? cs.paddingLeft : '2px';
      const blur = style === 'blur' || t.occlusion === DIMMED;
      el.textContent = blur ? '' : t.text;
      el.classList.toggle('blur', blur);
      const info = TAXONOMY[t.target.category];
      el.title = info ? `${info.teksAwam} (${info.dasarHukum}). Klik untuk menampilkan sementara.` : '';
      if (!el.classList.contains('on')) requestAnimationFrame(() => el.classList.add('on'));
    });
    for (let i = targets.length; i < pool.length; i++) {
      pool[i].classList.remove('on');
      pool[i].remove();
      pool[i]._target = null;
    }
    if (!usedTop) hideTopHost();
    metrics.covers = targets.length;
    if (metrics.firstPaintMs == null && metrics.lastActivatedAt != null) {
      metrics.firstPaintMs = Math.round(performance.now() - metrics.lastActivatedAt);
    }
    frame = requestAnimationFrame(render); // ikut scroll, resize, dan perubahan tata letak
  }

  function setActive(on) {
    if (on === active) return;
    active = on;
    if (on) {
      bgCache = new WeakMap();
      pinCache = new WeakMap();
      clipCache = new WeakMap();
      occlusionCache = new WeakMap();
      metrics.lastActivatedAt = performance.now();
      metrics.firstPaintMs = null;
      render();
    } else {
      if (frame != null) cancelAnimationFrame(frame);
      frame = null;
      revealAllUntil = 0;
      pool.forEach(el => { el.classList.remove('on'); el.remove(); el._target = null; });
      hideTopHost();
      metrics.covers = 0;
    }
  }

  return {
    setActive,
    isActive: () => active,
    // 'maksimal' mencakup semua KETAT; kategori PILIHAN datang lewat p
    setMode(m, p = []) { mode = m === 'ketat' || m === 'maksimal' ? 'ketat' : 'bawaan'; pilihan = Array.isArray(p) ? p : []; },
    setStyle(s) { style = s === 'blur' ? 'blur' : 'opak'; },
    revealAll(ms = revealTimeoutMs) { revealAllUntil = performance.now() + ms; },
    metrics: () => ({ ...metrics })
  };
}
