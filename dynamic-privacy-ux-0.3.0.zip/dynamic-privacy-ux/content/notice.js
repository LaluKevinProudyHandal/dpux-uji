/**
 * extension/content/notice.js
 * Pemberitahuan di halaman, mengikuti docs/spesifikasi-interaksi-ux.md bagian C★:
 * - C-1 / C-5 (T5): toast netral di kanan bawah, hilang setelah toastDurationMs, sekali per kejadian,
 *   jeda toastCooldownMs antar-toast; role=status + aria-live=polite; tanpa tombol.
 * - C-7: kamera tidak tersedia → satu pemberitahuan (sekali per sesi, diatur service worker)
 *   dengan pilihan "Samarkan terus sampai kamera kembali".
 * Ditaruh di shadow root tertutup agar gaya situs tidak memengaruhi, dan sebaliknya.
 */

import { OWN_ATTR } from './scanner.js';

export const TOAST_TEXT = 'Mode privasi aktif. Data pribadi disamarkan sementara.';
// Istilah sama dengan popup (glosarium, keputusan 23 Okt): "perlindungan", "disamarkan"
export const CAMERA_TEXT = 'Perlindungan otomatis berhenti: kamera tidak tersedia.';
export const COVERED_TEXT = 'Kamera tertutup. Perlindungan otomatis berhenti sampai lensa dibuka.';
export const CAMERA_ACTION = 'Samarkan terus sampai kamera kembali';

const CSS_TEXT = `
:host { all: initial; }
.wrap {
  position: fixed; right: 16px; bottom: 16px; z-index: 2147483647;
  display: grid; gap: 8px; justify-items: end; max-width: min(360px, calc(100vw - 32px));
  font: 14px/1.4 'Segoe UI', system-ui, sans-serif;
}
.box {
  box-sizing: border-box; padding: 10px 14px; border-radius: 10px;
  background: #1e293b; color: #f8fafc; box-shadow: 0 4px 16px rgba(15, 23, 42, 0.25);
  opacity: 0; transform: translateY(6px); transition: opacity 160ms ease-out, transform 160ms ease-out;
}
.box.on { opacity: 1; transform: none; }
.box[hidden] { display: none; }
.camera { display: grid; gap: 8px; }
.row { display: flex; gap: 8px; flex-wrap: wrap; }
button {
  font: inherit; font-size: 13px; padding: 6px 10px; border-radius: 8px; cursor: pointer;
  border: 1px solid #475569; background: transparent; color: #f8fafc;
}
button.primary { background: #f8fafc; color: #0f172a; border-color: #f8fafc; font-weight: 600; }
button:focus-visible { outline: 2px solid #93c5fd; outline-offset: 2px; }
@media (prefers-reduced-motion: reduce) { .box { transition: none; } }
`;

/**
 * @param {Document} doc
 * @param {{ toastDurationMs?: number, toastCooldownMs?: number, now?: () => number, shadowMode?: 'open'|'closed' }} [options]
 */
export function createNotifier(doc, { toastDurationMs = 4000, toastCooldownMs = 60000, now = () => performance.now(), shadowMode = 'closed' } = {}) {
  let host = null;
  let toastEl = null;
  let cameraEl = null;
  let hideTimer = null;
  let lastToastAt = -Infinity;

  function ensureHost() {
    if (host?.isConnected) return;
    host = doc.createElement('div');
    host.setAttribute(OWN_ATTR, 'notice'); // diabaikan pemindai
    host.style.cssText = 'position:fixed;width:0;height:0;margin:0;padding:0;border:0;z-index:2147483647;';
    const root = host.attachShadow({ mode: shadowMode }); // 'open' hanya untuk uji otomatis
    const styleEl = doc.createElement('style');
    styleEl.textContent = CSS_TEXT;
    const wrap = doc.createElement('div');
    wrap.className = 'wrap';
    // Wilayah aria-live harus sudah ada sebelum teksnya diisi, agar pembaca layar mengumumkannya
    toastEl = doc.createElement('div');
    toastEl.className = 'box toast';
    toastEl.setAttribute('role', 'status');
    toastEl.setAttribute('aria-live', 'polite');
    toastEl.hidden = true;
    cameraEl = doc.createElement('div');
    cameraEl.className = 'box camera';
    cameraEl.setAttribute('role', 'status');
    cameraEl.hidden = true;
    wrap.append(cameraEl, toastEl);
    root.append(styleEl, wrap);
    (doc.documentElement ?? doc.body).appendChild(host);
  }

  function showBox(el) {
    el.hidden = false;
    requestAnimationFrame(() => el.classList.add('on'));
  }

  function hideBox(el) {
    if (!el) return;
    el.classList.remove('on');
    el.hidden = true;
  }

  /** Toast "mode privasi aktif" (T5). Mengembalikan true bila benar-benar ditampilkan. */
  function privacyToast() {
    const t = now();
    if (t - lastToastAt < toastCooldownMs) return false;
    lastToastAt = t;
    ensureHost();
    clearTimeout(hideTimer);
    toastEl.textContent = TOAST_TEXT;
    showBox(toastEl);
    hideTimer = setTimeout(() => hideBox(toastEl), toastDurationMs);
    return true;
  }

  /** Pemberitahuan kamera tidak tersedia (C-7); tetap tampil sampai pengguna memilih. */
  function cameraNotice({ onFallback, reason = 'camera' }) {
    ensureHost();
    const text = doc.createElement('span');
    text.textContent = reason === 'covered' ? COVERED_TEXT : CAMERA_TEXT;
    const fallback = doc.createElement('button');
    fallback.type = 'button';
    fallback.className = 'primary';
    fallback.textContent = CAMERA_ACTION;
    fallback.addEventListener('click', () => { hideBox(cameraEl); onFallback(); });
    const close = doc.createElement('button');
    close.type = 'button';
    close.textContent = 'Tutup';
    close.addEventListener('click', () => hideBox(cameraEl));
    const row = doc.createElement('div');
    row.className = 'row';
    row.append(fallback, close);
    cameraEl.replaceChildren(text, row);
    showBox(cameraEl);
    return true;
  }

  return {
    privacyToast,
    cameraNotice,
    hideCameraNotice: () => hideBox(cameraEl),
    hideToast: () => { clearTimeout(hideTimer); hideBox(toastEl); }
  };
}
