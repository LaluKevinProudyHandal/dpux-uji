/**
 * extension/offscreen/offscreen.js
 * "Mata dan otak": kamera → MediaPipe → vision-core, berjalan di latar.
 * Offscreen document hanya punya chrome.runtime, jadi semua hasil dikirim lewat pesan ke service worker.
 * Yang dikirim hanya status dan angka ringkas; gambar kamera tidak pernah keluar dari halaman ini.
 *
 * Kamera sesuai kebutuhan (fondasi v1.5a): model dimuat sekali dan tetap siap, sedangkan kamera
 * (dan lampunya) dinyalakan/dimatikan atas perintah service worker ('vision-camera'). Menyalakan
 * kamera saja jauh lebih cepat daripada memuat ulang model.
 */

import { FaceLandmarker, FilesetResolver } from '../vendor/mediapipe/vision_bundle.mjs';
import { initFaceLandmarker, createVisionPipeline, createSessionLog } from '../vendor/vision-core/index.js';

const DETECT_INTERVAL_MS = 100; // 10× per detik, sama dengan demo
// Daftar wajah di popup diperbarui tiap detik, dan langsung saat jumlah wajah berubah
// (uji 19 Okt: daftar tertinggal sampai 2 dtk sehingga tampak tidak cocok dengan status)
const STATS_INTERVAL_MS = 1000;
const STATS_MIN_GAP_MS = 250;
// Bila gambar kamera tidak bergerak selama ini, kamera dianggap diambil aplikasi lain (C-7)
const STALL_MS = 5000;
// Lensa tertutup (slider privasi) → gambar rata hitam/abu: kamera "jalan" tapi tidak melihat apa-apa.
// Tanpa cek ini sistem melapor "Aman" padahal buta (temuan uji Kevin 18 Okt).
const COVER_CHECK_MS = 1000;
const COVER_HOLD_MS = 2000;     // harus rata selama ini sebelum dianggap tertutup
const COVER_MAX_STD = 6;        // simpangan baku kecerahan (0–255): gambar nyata jauh di atas ini
const COVER_MAX_MEAN_DARK = 18; // atau sangat gelap
const COVER_MAX_STD_DARK = 12;
// Setelah kamera menyala, data tetap disamarkan sampai mesin sempat mengamati selama "rem" tatapan
// ditambah sedikit cadangan; pengintip yang sudah ada sejak awal pasti terdeteksi dalam waktu ini.
const WARM_MARGIN_MS = 300;
const WARM_MIN_FRAMES = 3;

/** Kecerahan rata-rata dan simpangan bakunya dari gambar kecil 32×24 (murah, tanpa menyimpan gambar). */
function frameStats(ctx, source) {
  ctx.drawImage(source, 0, 0, 32, 24);
  const px = ctx.getImageData(0, 0, 32, 24).data;
  let sum = 0, sumSq = 0;
  const n = px.length / 4;
  for (let i = 0; i < px.length; i += 4) {
    const y = 0.299 * px[i] + 0.587 * px[i + 1] + 0.114 * px[i + 2];
    sum += y; sumSq += y * y;
  }
  const mean = sum / n;
  return { mean, std: Math.sqrt(Math.max(0, sumSq / n - mean * mean)) };
}

function looksCovered({ mean, std }) {
  return std < COVER_MAX_STD || (mean < COVER_MAX_MEAN_DARK && std < COVER_MAX_STD_DARK);
}

const video = document.getElementById('camera');

function send(message) {
  chrome.runtime.sendMessage(message).catch(() => { /* service worker sedang bangun; pesan berikutnya menyusul */ });
}

let landmarker = null;
let config = null;
let log = null;
let camera = null;          // sesi kamera yang sedang menyala, atau null
let cameraRequest = false;  // keinginan terakhir dari service worker
let switching = Promise.resolve();
let openedBefore = false;   // kamera pernah menyala di dokumen ini

/** Menyalakan kamera dan memulai pengamatan. */
async function startCamera() {
  if (camera) return;
  let stream;
  try {
    stream = await navigator.mediaDevices.getUserMedia({
      video: { width: { ideal: 640 }, height: { ideal: 480 }, facingMode: 'user' },
      audio: false
    });
  } catch (err) {
    // Membuka ulang kamera di dokumen yang sama bisa gagal setelah kamera padam beberapa detik
    // (uji Chrome headless 22 Okt: NotFoundError, padahal kamera ada). Dokumen baru selalu bisa membukanya,
    // jadi service worker membuat ulang dokumen ini; data tetap disamarkan selama masa bersiap.
    if (openedBefore && err.name !== 'NotAllowedError') {
      send({ type: 'vision-reopen-failed', detail: `${err.name}: ${err.message}` });
      return;
    }
    // NotReadableError = kamera sedang dipakai aplikasi lain (mis. Zoom/Meet)
    send({ type: 'vision-error', reason: err.name === 'NotAllowedError' ? 'permission' : 'camera', detail: `${err.name}: ${err.message}` });
    return;
  }
  openedBefore = true;
  video.srcObject = stream;
  await video.play();

  const width = video.videoWidth || 640;
  const height = video.videoHeight || 480;
  // Pipeline baru tiap kali kamera menyala: pelacak dan rem tidak mewarisi keadaan dari sesi sebelumnya
  const pipeline = createVisionPipeline(config?.settings ?? {});
  log ??= createSessionLog({
    meta: {
      extensionVersion: config?.extensionVersion ?? null,
      delegate: landmarker.delegate,
      videoWidth: width,
      videoHeight: height,
      detectIntervalMs: DETECT_INTERVAL_MS,
      brake: { threatOnMs: pipeline.config.threatOnMs, threatOffMs: pipeline.config.threatOffMs },
      config: pipeline.config
    }
  });

  const session = {
    stream, timer: null, lost: false,
    startedAt: performance.now(), warmSent: false,
    lastVideoTime: -1, lastLevel: null, frames: 0, framesSinceStart: 0, people: [],
    statsSince: performance.now(), lastFaceCount: 0, lastFrameAt: performance.now(),
    coverCtx: new OffscreenCanvas(32, 24).getContext('2d', { willReadFrequently: true }),
    coverCheckAt: 0, coveredSince: null, covered: false
  };
  camera = session;

  // Kamera bisa hilang di tengah sesi: dicabut, izin ditarik, atau diambil aplikasi lain (C-7)
  const loseCamera = (detail) => {
    if (session.lost) return;
    session.lost = true;
    stopCamera({ silent: true });
    send({ type: 'vision-error', reason: 'camera', detail });
  };
  for (const track of stream.getVideoTracks()) {
    track.addEventListener('ended', () => loseCamera('track-ended'));
  }

  send({ type: 'vision-camera', on: true });

  session.timer = setInterval(() => {
    const now = performance.now();
    if (video.currentTime === session.lastVideoTime) {
      if (now - session.lastFrameAt > STALL_MS) loseCamera('stalled');
      return;
    }
    session.lastVideoTime = video.currentTime;
    session.lastFrameAt = now;

    // Mesin tetap berjalan saat lensa tertutup, supaya langsung pulih begitu dibuka
    if (now - session.coverCheckAt >= COVER_CHECK_MS) {
      session.coverCheckAt = now;
      const flat = looksCovered(frameStats(session.coverCtx, video));
      session.coveredSince = flat ? (session.coveredSince ?? now) : null;
      const nowCovered = session.coveredSince != null && now - session.coveredSince >= COVER_HOLD_MS;
      if (nowCovered !== session.covered) {
        session.covered = nowCovered;
        send({ type: 'vision-covered', covered: nowCovered });
      }
    }

    const result = landmarker.detectForVideo(video, now);
    const out = pipeline.process(result.faceLandmarks ?? [], width, height, now);
    log.record(out);
    session.frames++;
    session.framesSinceStart++;
    // Ringkasan per wajah untuk diagnostik: peran dan jarak saja, tanpa gambar atau titik wajah
    session.people = out.visibleTracks.map(tr => ({
      id: tr.id,
      role: out.ownerTrack && tr.id === out.ownerTrack.id ? 'owner'
        : tr.gazeAnalysis.isFacingScreen ? 'looking' : 'away',
      distanceM: tr.distanceM == null ? null : Math.round(tr.distanceM * 10) / 10
    }));

    // Kirim hanya saat status berubah, supaya service worker tidak dibangunkan 10× per detik
    if (out.level !== session.lastLevel) {
      session.lastLevel = out.level;
      send({ type: 'vision-level', level: out.level });
    }

    // Masa yakin selesai: penyamaran "bersiap" boleh dilepas, status kamera yang berlaku
    if (!session.warmSent && session.framesSinceStart >= WARM_MIN_FRAMES
      && now - session.startedAt >= pipeline.config.threatOnMs + WARM_MARGIN_MS) {
      session.warmSent = true;
      send({ type: 'vision-warm', level: out.level });
    }

    const faceCountChanged = session.people.length !== session.lastFaceCount && now - session.statsSince >= STATS_MIN_GAP_MS;
    if (faceCountChanged || now - session.statsSince >= STATS_INTERVAL_MS) {
      session.lastFaceCount = session.people.length;
      send({
        type: 'vision-stats', fps: Math.round((session.frames * 1000) / (now - session.statsSince)),
        faces: session.people.length, people: session.people, delegate: landmarker.delegate
      });
      session.frames = 0;
      session.statsSince = now;
    }
  }, DETECT_INTERVAL_MS);
}

/** Mematikan kamera (lampu padam); model tetap siap. */
function stopCamera({ silent = false } = {}) {
  if (!camera) return;
  clearInterval(camera.timer);
  camera.stream.getTracks().forEach(t => t.stop());
  video.srcObject = null;
  camera = null;
  if (!silent) send({ type: 'vision-camera', on: false });
}

/** Menyelaraskan kamera dengan keinginan terakhir; perintah beruntun dijalankan berurutan. */
function applyCameraRequest() {
  switching = switching.then(async () => {
    if (cameraRequest) await startCamera();
    else stopCamera();
  }).catch((err) => {
    console.error('[offscreen] Kamera gagal:', err);
    send({ type: 'vision-error', reason: 'internal', detail: err?.message ?? String(err) });
  });
}

// Popup meminta log langsung ke halaman ini; service worker mengatur kamera. Pesan lain diabaikan.
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  switch (message?.type) {
    case 'vision-get-log':
      sendResponse(log?.exportData() ?? null); return false;
    case 'vision-log-summary':
      sendResponse(log?.summary() ?? { frames: 0, durationMs: 0, levelChanges: 0 }); return false;
    case 'vision-clear-log':
      log?.clear(); sendResponse(log?.summary() ?? null); return false;
    case 'vision-set-camera':
      cameraRequest = Boolean(message.on);
      if (landmarker) applyCameraRequest(); // sebelum model siap, keinginan ini dipakai saat init selesai
      sendResponse(true); return false;
    default:
      return false;
  }
});

async function init() {
  try {
    landmarker = await initFaceLandmarker(FilesetResolver, FaceLandmarker, {}, {
      wasmBasePath: chrome.runtime.getURL('vendor/mediapipe/wasm'),
      modelAssetPath: chrome.runtime.getURL('vendor/mediapipe/face_landmarker.task')
    });
  } catch (err) {
    send({ type: 'vision-error', reason: 'model', detail: err.message });
    return;
  }
  // Pengaturan "rem" dan keinginan kamera dari service worker (offscreen document tidak punya chrome.storage);
  // versi extension ikut dikirim karena di sini hanya ada API pesan + getURL
  config = await chrome.runtime.sendMessage({ type: 'vision-get-config' }).catch(() => null);
  cameraRequest = Boolean(config?.cameraOn);
  send({ type: 'vision-ready', delegate: landmarker.delegate });
  applyCameraRequest();
}

// Kegagalan tak terduga harus terlihat di popup, bukan diam-diam macet (fondasi.md P7)
init().catch((err) => {
  console.error('[offscreen] Mesin visi gagal:', err);
  send({ type: 'vision-error', reason: 'internal', detail: err?.message ?? String(err) });
});
