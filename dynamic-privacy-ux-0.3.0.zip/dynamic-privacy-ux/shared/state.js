/**
 * extension/shared/state.js
 * Status extension yang disimpan di chrome.storage.local.
 * Disimpan di storage (bukan variabel) karena service worker MV3 bisa "tidur" kapan saja.
 */

export const LEVEL = Object.freeze({
  OFF: 'off',         // Perlindungan dimatikan pengguna
  SAFE: 'safe',       // Hanya pemilik
  AWARE: 'aware',     // Ada orang lain, tidak melihat layar
  THREAT: 'threat',   // Ada orang lain yang melihat layar
  UNKNOWN: 'unknown', // Kamera belum aktif / bermasalah
  PAUSED: 'paused',   // Dijeda sementara oleh pengguna (C-6, "Jeda 10 menit")
  STANDBY: 'standby', // Kamera istirahat: tab aktif tidak berisi data yang disamarkan (fondasi v1.5a)
  WARMING: 'warming'  // Kamera baru menyala dan belum yakin: data disamarkan dulu, tanpa pemberitahuan
});

/** Status yang membuat halaman menutup data. */
export const MASKING_LEVELS = Object.freeze([LEVEL.THREAT, LEVEL.WARMING]);

// Preset "rem" (fondasi.md RB4): bawaan proyek vs. nilai bawaan Windows Onlooker Detection (A5)
export const BRAKE_PRESETS = Object.freeze({
  on: { default: 300, windows: 2000 },   // tatapan sebelum penyamaran aktif (ms)
  off: { default: 1500, windows: 5000 }  // aman sebelum penyamaran dilepas (ms)
});

export const DEFAULT_SETTINGS = Object.freeze({
  threatOnMs: BRAKE_PRESETS.on.default,
  threatOffMs: BRAKE_PRESETS.off.default,
  // Satu kontrol bertingkat (keputusan 28 Okt): 'bawaan' = Standar (SELALU) · 'ketat' = Tinggi (+ KETAT)
  // · 'maksimal' = Maksimal (+ PILIHAN: nama, alamat, tanggal lahir). Tingkatnya bersarang: SELALU ⊂ KETAT ⊂ PILIHAN.
  maskMode: 'bawaan',
  maskStyle: 'opak',    // 'opak' | 'blur' (KS3)
  simulateLevel: null,  // null | 'threat' — alat penelitian: paksa status tanpa kamera
  cameraMode: 'kebutuhan' // 'kebutuhan' (menyala hanya di tab berisi data sensitif) | 'selalu' (alat penelitian, E1)
});

// Kategori PILIHAN (sensitive-core/taxonomy.js PILIHAN_CATEGORIES); disalin karena service worker tidak dibundel
export const PILIHAN_CATEGORIES = Object.freeze(['K11', 'K12', 'K13']);

/** Kategori PILIHAN yang berlaku untuk tingkat perlindungan ini. */
export const pilihanFor = (maskMode) => (maskMode === 'maksimal' ? [...PILIHAN_CATEGORIES] : []);

// Pengaturan yang mengubah perilaku mesin visi (perlu mulai ulang kamera bila berubah)
export const VISION_SETTING_KEYS = Object.freeze(['threatOnMs', 'threatOffMs']);

// Lama "Jeda 10 menit" di popup (C-6)
export const PAUSE_MS = 10 * 60 * 1000;

// Jeda per situs (keputusan 28 Okt): 1 jam, atau sampai dilanjutkan pengguna
export const SITE_PAUSE = Object.freeze({ hour: 60 * 60 * 1000, forever: Number.MAX_SAFE_INTEGER });

/** Kunci situs = origin http(s) halaman teratas; null untuk halaman lain (chrome://, PDF). */
export function siteKey(url) {
  try {
    const u = new URL(url);
    return /^https?:$/.test(u.protocol) ? u.origin : null;
  } catch { return null; }
}

/** Batas waktu jeda situs ini (epoch ms), atau 0 bila tidak dijeda. */
export function sitePausedUntil(sitePauses, site, now = Date.now()) {
  const until = site ? (sitePauses?.[site] ?? 0) : 0;
  return until > now ? until : 0;
}

/**
 * Apakah kamera perlu menyala (fondasi v1.5a, "kamera sesuai kebutuhan").
 * Mesin visi (model) boleh tetap siap di latar; yang diatur di sini hanya kamera — dan lampunya.
 * @param {object} state status tersimpan
 * @param {number} activeTabFindings jumlah data di tab aktif yang akan disamarkan pada mode terpilih
 */
export function cameraNeeded({ enabled, pausedUntil, error, settings }, activeTabFindings, now = Date.now()) {
  if (!enabled || pausedUntil > now || error === 'permission') return false;
  if (settings?.cameraMode === 'selalu') return true;
  return activeTabFindings > 0;
}

/**
 * Status yang dipakai badge dan halaman. Urutan prioritas:
 * mati → dijeda → simulasi (alat penelitian) → kamera bermasalah (C-7) → kamera sedang bersiap → status kamera.
 */
export function effectiveLevel({ enabled, level, settings, pausedUntil, error, cameraFallback, warming }, now = Date.now()) {
  if (!enabled) return LEVEL.OFF;
  if (pausedUntil > now) return LEVEL.PAUSED;
  if (settings?.simulateLevel) return settings.simulateLevel;
  // Kamera bermasalah = sistem buta: jangan pernah mengaku "Aman" (temuan uji 18 Okt, lensa ditutup)
  if (error) return cameraFallback ? LEVEL.THREAT : LEVEL.UNKNOWN;
  // Kamera baru menyala: belum bisa memastikan tidak ada pengintip → tutup dulu (gagal-tertutup)
  if (warming) return LEVEL.WARMING;
  return level;
}

/** Pesan status untuk content script (T4). */
export function contentPayload(state, now = Date.now()) {
  const settings = { ...DEFAULT_SETTINGS, ...state.settings };
  return {
    type: 'dpux-state', level: effectiveLevel({ ...state, settings }, now),
    maskMode: settings.maskMode, maskStyle: settings.maskStyle,
    pilihan: pilihanFor(settings.maskMode), sitePauses: state.sitePauses ?? {}
  };
}

export const DEFAULT_STATE = Object.freeze({
  enabled: true,
  settings: DEFAULT_SETTINGS,
  level: LEVEL.UNKNOWN,
  error: null,   // null | 'permission' | 'camera' | 'covered' | 'model' | 'internal'
  errorDetail: null, // teks teknis galat terakhir (mis. "NotReadableError: …", "stalled"), untuk diagnosis
  stats: null,   // { fps, faces, delegate } dari mesin visi, diperbarui tiap detik
  pausedUntil: 0,       // epoch ms; > sekarang berarti perlindungan dijeda (C-6)
  sitePauses: {},       // { [origin]: epoch ms } jeda per situs (keputusan 28 Okt)
  cameraFallback: false, // pengguna memilih "Samarkan terus sampai kamera kembali" (C-7)
  cameraActive: false,   // kamera sedang menyala (lampu menyala)
  warming: false         // kamera baru menyala, belum melewati masa yakin
});

export async function getState() {
  const stored = await chrome.storage.local.get(Object.keys(DEFAULT_STATE));
  const state = { ...DEFAULT_STATE, ...stored };
  // Pengaturan baru (mis. cameraMode) harus punya nilai bawaan walau storage berisi pengaturan versi lama
  state.settings = { ...DEFAULT_SETTINGS, ...stored.settings };
  return state;
}

export async function setState(patch) {
  await chrome.storage.local.set(patch);
  return getState();
}
