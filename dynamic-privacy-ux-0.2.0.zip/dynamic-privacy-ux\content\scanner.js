/**
 * extension/content/scanner.js
 * Pemindai halaman (T2): mencari data sensitif di teks dan kolom formulir, lalu mengikuti perubahan halaman.
 *
 * Keputusan T2 (fondasi.md bagian 8, v1.1):
 * - Pindai sejak halaman dibuka, saat browser senggang (requestIdleCallback), dalam potongan kecil.
 * - Perubahan dipindai sebagian lewat MutationObserver dengan jeda ±250 ms.
 * - Yang disimpan hanya referensi node/elemen + kategori + posisi karakter. Posisi di layar dihitung nanti
 *   saat penyamaran akan tampil (T3). Tidak ada isi halaman yang dikirim ke mana pun.
 * - Semua kategori disimpan (mode 'semua'); penyaringan bawaan/ketat dilakukan saat menyamarkan,
 *   sehingga mengganti mode tidak perlu memindai ulang.
 */

import { detectSensitive, classifyField, TAXONOMY } from '../../sensitive-core/index.js';

const MUTATION_DEBOUNCE_MS = 250;
const MAX_LABEL_CHARS = 60;
// Label dari elemen lain hanya berlaku untuk NILAI pendek ("Rp 4.250.000", "J45.9 Asma"), bukan kalimat.
// Temuan uji Chrome 18 Okt: judul "2. Label dan nilai…" dipakai sebagai label kalimat OTP → salah dikenali sebagai Nilai.
const MAX_SEPARATE_VALUE_CHARS = 40;
const SKIP_TAGS = new Set(['SCRIPT', 'STYLE', 'NOSCRIPT', 'TEMPLATE', 'IFRAME', 'OBJECT', 'EMBED', 'SVG', 'CANVAS',
  'HEAD', 'TITLE', 'META', 'LINK', 'TEXTAREA', 'SELECT', 'OPTION']);
const FIELD_SELECTOR = 'input, textarea';
const SKIP_INPUT_TYPES = new Set(['hidden', 'submit', 'button', 'reset', 'checkbox', 'radio', 'file', 'image', 'range', 'color']);
// Penanda elemen milik extension (overlay T3/T5) agar tidak ikut dipindai
export const OWN_ATTR = 'data-dpux';

const short = (s) => {
  const t = (s ?? '').replace(/\s+/g, ' ').trim();
  return t.length > 0 && t.length <= MAX_LABEL_CHARS ? t : '';
};

function isOwn(node) {
  const el = node.nodeType === Node.ELEMENT_NODE ? node : node.parentElement;
  return Boolean(el?.closest?.(`[${OWN_ATTR}]`));
}

// ------------------------------------------------------------------ label di dekat sebuah nilai

/** Teks node sebelumnya di elemen yang sama, melewati <br> dan spasi ("NIK<br>3471…"). */
function previousTextInSameParent(textNode) {
  for (let n = textNode.previousSibling; n; n = n.previousSibling) {
    if (n.nodeType === Node.TEXT_NODE && n.nodeValue.trim()) return short(n.nodeValue);
    if (n.nodeType === Node.ELEMENT_NODE && n.tagName !== 'BR') return short(n.textContent);
  }
  return '';
}

/** Judul kolom tabel untuk sebuah sel. */
function tableHeaderFor(el) {
  const cell = el.closest('td');
  const table = cell?.closest('table');
  if (!cell || !table) return '';
  const headerRow = table.tHead?.rows[0] ?? table.rows[0];
  if (!headerRow || headerRow === cell.parentElement) return '';
  return short(headerRow.cells[cell.cellIndex]?.textContent);
}

/**
 * Label untuk nilai yang berdiri sendiri di elemennya, mis. <dt>NIK</dt><dd>3404…</dd> atau
 * <div><span>Saldo</span><b>Rp…</b></div>. Hanya dipakai bila teks node = seluruh isi elemennya.
 */
const INLINE_TAGS = new Set(['B', 'STRONG', 'SPAN', 'EM', 'I', 'CODE', 'A', 'SMALL', 'MARK', 'U']);

/** Teks sebaris tepat sebelum node, termasuk di luar elemen inline pembungkusnya ("Contoh <b>…</b>"). */
const INLINE_BEFORE_CHARS = 40;

/**
 * Teks sebaris tepat sebelum node, dikumpulkan dari beberapa saudara sampai ±40 karakter.
 * Uji WhatsApp 23 Okt: kalimat dipecah menjadi teks + emoji <img alt="❤️"> + tautan angka,
 * sehingga "saldo ❤️ Rp <tautan>4.250.000</tautan>" harus dibaca sebagai satu kalimat.
 */
function inlineTextBefore(textNode) {
  let out = '';
  let cur = textNode;
  while (cur && out.length < INLINE_BEFORE_CHARS) {
    let n = cur.previousSibling;
    if (!n) {
      const parent = cur.parentElement;
      if (!parent || !INLINE_TAGS.has(parent.tagName)) break;
      cur = parent; // keluar dari pembungkus sebaris (tautan, tebal)
      continue;
    }
    if (n.nodeType === Node.TEXT_NODE) out = n.nodeValue + out;
    else if (n.nodeType === Node.ELEMENT_NODE) {
      if (n.tagName === 'BR') break;
      if (n.tagName === 'IMG') out = (n.getAttribute('alt') ?? '') + out;
      else if (INLINE_TAGS.has(n.tagName)) out = (n.textContent ?? '') + out;
      else break; // elemen blok: bukan lagi kalimat yang sama
    }
    cur = n;
  }
  return out.slice(-INLINE_BEFORE_CHARS);
}

/**
 * Paragraf panjang yang diakhiri titik dua: kalimat terakhirnya adalah label nilai di bawahnya
 * ("…permintaan. Berikut kode OTP-mu:" → kotak berisi kode). Temuan uji Gmail 21 Okt.
 */
function labelTail(text) {
  const t = (text ?? '').trim();
  if (!t.endsWith(':')) return '';
  return short(t.split(/[.!?]\s+/).pop());
}

// Tulisan tombol adalah perintah, bukan nilai: tidak boleh meminjam label dari elemen lain
// (Shopee 22 Okt: judul "Reset Password" + tombol "BERIKUTNYA" → tombol dikira kata sandi).
// Label di dalam tombol itu sendiri ("Rek. BCA 1234567890") tetap dikenali aturan sebaris.
const CONTROLS = 'button, [role="button"], [role="tab"], [role="menuitem"], [role="option"], summary, select';

// Baris hitungan jawaban di antara judul pertanyaan dan jawabannya ("Nomor Rekening" ⏎ "1 jawaban" ⏎ nilai).
// Uji Google Forms 28 Okt: halaman ringkasan jawaban memakai "1 jawaban" sebagai label → rekening dan OTP lolos.
// Tanpa \b: isi gabungan bisa menempel ("Nomor Rekening1 jawaban")
const COUNT_SUFFIX = /\s*\d+\s*(?:jawaban|respons|responses?|tanggapan|answers?)$/i;

/** Label calon tanpa baris hitungan jawaban; '' bila isinya hanya hitungan. */
const withoutCount = (text) => short(text.replace(COUNT_SUFFIX, ''));

/**
 * Isi teks sebuah calon label tanpa tulisan tombol di dalamnya. Uji Google Forms 28 Okt: wadah judul berisi
 * "Nomor Rekening" + "1 jawaban" + tombol tersembunyi "Salin diagram" → labelnya tidak dikenali.
 */
function textWithoutControls(node) {
  if (node.nodeType !== Node.ELEMENT_NODE || !node.querySelector(CONTROLS)) return node.textContent ?? '';
  const walker = node.ownerDocument.createTreeWalker(node, NodeFilter.SHOW_TEXT);
  let out = '';
  for (let t = walker.nextNode(); t; t = walker.nextNode()) {
    if (!t.parentElement?.closest(CONTROLS) || !node.contains(t.parentElement.closest(CONTROLS))) out += t.nodeValue;
  }
  return out;
}

function labelForText(textNode) {
  const el = textNode.parentElement;
  if (!el || textNode.nodeValue.trim().length > MAX_SEPARATE_VALUE_CHARS) return '';
  if (el.closest(CONTROLS)) return '';
  // Baris hitungan ("1 jawaban") bukan nilai, jadi tidak meminjam label ("Nama Lengkap" → "1 jawaban" dikira nama)
  if (COUNT_SUFFIX.test(textNode.nodeValue.trim()) && !withoutCount(textNode.nodeValue)) return '';
  if (short(el.textContent) !== short(textNode.nodeValue) && el.textContent.trim() !== textNode.nodeValue.trim()) {
    return previousTextInSameParent(textNode);
  }
  // Sel tabel: judul kolom lebih dapat dipercaya daripada sel di sebelahnya ("Gaji Oktober" | "Rp…")
  const header = tableHeaderFor(el);
  if (header) return header;
  for (let cur = el, depth = 0; cur && depth < 3; cur = cur.parentElement, depth++) {
    // Saudara berupa teks lepas juga dihitung: "Kode OTP Shopee kamu:" <div><b>kode</b></div>
    // (uji Gmail 22 Okt: hanya melihat elemen membuat "Hai ," di atasnya dipakai sebagai label)
    for (let prev = cur.previousSibling; prev; prev = prev.previousSibling) {
      if (prev.nodeType !== Node.ELEMENT_NODE && prev.nodeType !== Node.TEXT_NODE) continue;
      if (prev.nodeType === Node.ELEMENT_NODE && (prev.tagName === 'BR' || isOwn(prev))) continue;
      const content = textWithoutControls(prev);
      const raw = short(content);
      if (raw && COUNT_SUFFIX.test(raw) && !withoutCount(raw)) continue; // hanya "1 jawaban": lewati
      const text = (raw && withoutCount(raw)) || labelTail(content);
      if (text) return text;
      if (content.trim()) break; // saudara panjang: bukan label
    }
    if ((cur.parentElement?.textContent.length ?? 0) > 300) break;
  }
  return precedingLabel(textNode);
}

/**
 * Cadangan: teks terakhir sebelum nilai dalam urutan baca, hanya bila diakhiri titik dua
 * ("Kode OTP Shopee kamu:" ⏎ <b>kode</b>). Tidak bergantung pada susunan HTML, yang di email
 * sangat beragam (uji Gmail 21 Okt: struktur yang sama bisa gagal di satu pengirim dan lolos di lainnya).
 */
const HEADINGS = 'h1, h2, h3, h4, h5, h6';

/**
 * Judul bagian tempat teks berada (judul terdekat sebelumnya, naik sampai 5 tingkat).
 * Dipakai untuk mengenali bagian contoh ("Example for computing check digit", Wikipedia 22 Okt);
 * TIDAK dipakai sebagai label (judul sebagai label pernah menimbulkan salah deteksi, 18 Okt).
 */
function sectionHeading(textNode) {
  let cur = textNode.parentElement;
  for (let depth = 0; cur && depth < 5; depth++, cur = cur.parentElement) {
    if (cur.matches?.(HEADINGS)) return '';
    let steps = 0;
    for (let prev = cur.previousElementSibling; prev && steps < 25; prev = prev.previousElementSibling, steps++) {
      if (prev.matches(HEADINGS)) return short(prev.textContent);
      const inner = prev.querySelectorAll(HEADINGS);
      if (inner.length) return short(inner[inner.length - 1].textContent);
    }
  }
  return '';
}

function precedingLabel(textNode) {
  const root = textNode.getRootNode();
  const walker = (root.ownerDocument ?? root).createTreeWalker(root, NodeFilter.SHOW_TEXT);
  walker.currentNode = textNode;
  for (let i = 0; i < 30; i++) {
    const prev = walker.previousNode();
    if (!prev) return '';
    if (!prev.nodeValue.trim() || isOwn(prev)) continue;
    return labelTail(prev.nodeValue);
  }
  return '';
}

function labelForField(field) {
  const byFor = field.id ? field.ownerDocument.querySelector(`label[for="${CSS.escape(field.id)}"]`) : null;
  const wrap = field.closest('label');
  const labelledBy = field.getAttribute('aria-labelledby')
    ?.split(/\s+/).map(id => field.ownerDocument.getElementById(id)?.textContent ?? '').join(' ');
  return short(byFor?.textContent) || short(wrap?.textContent) || short(labelledBy);
}

// ------------------------------------------------------------------ nilai yang terpecah ke beberapa node teks

const RUN_MAX_CHARS = 80;

/**
 * Nilai yang dipecah situs menjadi beberapa node teks ("4111" " 1111" …, atau <span> per kelompok angka).
 * Uji WhatsApp 23 Okt: nomor kartu berspasi lolos, sementara nomor tanpa spasi tertutup.
 * Teks pendek pembungkus sebaris digabung, dipindai sekali, lalu temuan yang melintasi node dipotong per node.
 */
function splitValueFindings(node) {
  let box = node.parentElement;
  // Naik hanya melalui pembungkus sebaris; berhenti di elemen blok (gelembung pesan berisi jam tidak ikut)
  while (box && INLINE_TAGS.has(box.tagName) && box.parentElement && INLINE_TAGS.has(box.parentElement.tagName)
    && (box.parentElement.textContent?.length ?? 0) <= RUN_MAX_CHARS) box = box.parentElement;
  if (!box || (box.textContent?.length ?? 0) > RUN_MAX_CHARS) return [];
  const walker = box.ownerDocument.createTreeWalker(box, NodeFilter.SHOW_TEXT);
  const nodes = [];
  for (let n = walker.nextNode(); n; n = walker.nextNode()) if (!isOwn(n)) nodes.push(n);
  if (nodes.length < 2) return [];
  let joined = '', offset = -1;
  for (const n of nodes) { if (n === node) offset = joined.length; joined += n.nodeValue; }
  if (offset < 0) return [];
  const end = offset + node.nodeValue.length;
  return detectSensitive(joined, { section: sectionHeading(node), mode: 'semua', pilihan: true })
    .filter(f => f.start < end && f.end > offset && (f.start < offset || f.end > end)) // melintasi node ini
    // partial = nilai berlanjut ke node berikutnya: potongan ini tidak boleh memperlihatkan "4 digit terakhir"-nya sendiri
    .map(f => ({ ...f, start: Math.max(f.start, offset) - offset, end: Math.min(f.end, end) - offset, partial: f.end > end, rule: `${f.rule}+terpecah` }))
    // Potongan tanpa angka ("Rp ") tidak perlu ditutup terpisah; angkanya sudah tertutup
    .filter(f => /\d/.test(node.nodeValue.slice(f.start, f.end)));
}

// ------------------------------------------------------------------ pemindai

/**
 * @param {Document} doc
 * @param {{ onChange?: (summary) => void }} [options]
 */
// Shadow root yang dipasang SETELAH elemennya dipindai tidak memicu MutationObserver apa pun.
// Uji X 28 Okt: pesan chat berada di shadow root seperti itu → tidak ada yang terdeteksi.
const SHADOW_SWEEP_MS = 2000;

export function createScanner(doc, { onChange, shadowSweepMs = SHADOW_SWEEP_MS } = {}) {
  /** @type {Map<Text, Array<{start:number,end:number,category:string,rule:string}>>} */
  const textFindings = new Map();
  /** @type {Map<Element, Array<{category:string,rule:string,start?:number,end?:number}>>} */
  const fieldFindings = new Map();
  const queue = [];           // root yang menunggu dipindai
  const pending = new Set();  // target mutasi yang menunggu jeda
  const observers = [];
  const observedRoots = new WeakSet();
  let idleHandle = null;
  let debounceTimer = null;
  let sweepTimer = null;
  const metrics = { scanMs: 0, textNodes: 0, fields: 0, passes: 0, lastPassMs: 0, startedAt: performance.now(), firstCompleteMs: null };

  function scanTextNode(node) {
    const text = node.nodeValue;
    if (!text || text.trim().length < 2) { textFindings.delete(node); return; }
    const found = detectSensitive(text, {
      label: labelForText(node), before: inlineTextBefore(node), section: sectionHeading(node), mode: 'semua', pilihan: true
    });
    for (const f of splitValueFindings(node)) {
      if (found.every(g => f.end <= g.start || f.start >= g.end)) found.push(f);
    }
    if (found.length) textFindings.set(node, found);
    else textFindings.delete(node);
    metrics.textNodes++;
  }

  function scanField(field) {
    const type = (field.getAttribute('type') || 'text').toLowerCase();
    if (field.tagName === 'INPUT' && SKIP_INPUT_TYPES.has(type)) return;
    const label = labelForField(field);
    const attrs = {
      type, name: field.name ?? '', id: field.id ?? '', autocomplete: field.getAttribute('autocomplete') ?? '',
      ariaLabel: field.getAttribute('aria-label') ?? '', placeholder: field.getAttribute('placeholder') ?? '', label
    };
    const findings = [];
    const category = classifyField(attrs);
    if (category) findings.push({ category, rule: 'kolom:atribut' });
    // Nilai yang sudah terisi (mis. kolom read-only berisi NIK) ikut diperiksa
    if (!category && field.value) {
      for (const f of detectSensitive(field.value, { label, mode: 'semua', pilihan: true })) findings.push({ ...f, rule: `kolom:${f.rule}` });
    }
    if (findings.length) fieldFindings.set(field, findings);
    else fieldFindings.delete(field);
    metrics.fields++;
  }

  /** Mengumpulkan text node, kolom, dan shadow root terbuka di bawah sebuah root. */
  function collect(root, out) {
    if (root.nodeType === Node.TEXT_NODE) { if (!isOwn(root)) out.texts.push(root); return; }
    if (root.nodeType === Node.ELEMENT_NODE) {
      if (isOwn(root)) return;
      if (root.matches(FIELD_SELECTOR)) { out.fields.push(root); return; }
      if (SKIP_TAGS.has(root.tagName)) return;
    }
    const walker = doc.createTreeWalker(root, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT, {
      acceptNode(n) {
        if (n.nodeType === Node.TEXT_NODE) return NodeFilter.FILTER_ACCEPT;
        if (n.hasAttribute(OWN_ATTR)) return NodeFilter.FILTER_REJECT;
        if (n.matches(FIELD_SELECTOR)) { out.fields.push(n); return NodeFilter.FILTER_REJECT; }
        if (SKIP_TAGS.has(n.tagName)) return NodeFilter.FILTER_REJECT;
        if (n.shadowRoot) out.shadows.push(n.shadowRoot);
        return NodeFilter.FILTER_SKIP;
      }
    });
    if (root.nodeType === Node.ELEMENT_NODE && root.shadowRoot) out.shadows.push(root.shadowRoot);
    for (let n = walker.nextNode(); n; n = walker.nextNode()) out.texts.push(n);
  }

  function observe(root) {
    if (observedRoots.has(root)) return;
    observedRoots.add(root);
    const mo = new MutationObserver(onMutations);
    mo.observe(root, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ['value'] });
    observers.push(mo);
  }

  function purgeDisconnected() {
    for (const node of textFindings.keys()) if (!node.isConnected) textFindings.delete(node);
    for (const el of fieldFindings.keys()) if (!el.isConnected) fieldFindings.delete(el);
  }

  // Pemindaian dalam potongan kecil saat browser senggang, agar halaman tidak tersendat
  let work = null; // { texts, fields, shadows }
  function runIdle(deadline) {
    idleHandle = null;
    const t0 = performance.now();
    const timeLeft = () => (deadline?.timeRemaining ? deadline.timeRemaining() : 8 - (performance.now() - t0));
    while (timeLeft() > 2) {
      if (!work || (!work.texts.length && !work.fields.length && !work.shadows.length)) {
        const root = queue.shift();
        if (!root) break;
        if (!root.isConnected && root.nodeType !== Node.DOCUMENT_FRAGMENT_NODE) continue;
        work = { texts: [], fields: [], shadows: [] };
        collect(root, work);
        continue;
      }
      if (work.shadows.length) { const sr = work.shadows.pop(); observe(sr); queue.push(sr); continue; }
      if (work.fields.length) { scanField(work.fields.pop()); continue; }
      scanTextNode(work.texts.pop());
    }
    metrics.scanMs += performance.now() - t0;
    const unfinished = queue.length || (work && (work.texts.length || work.fields.length || work.shadows.length));
    if (unfinished) schedule();
    else {
      metrics.passes++;
      metrics.lastPassMs = performance.now();
      if (metrics.firstCompleteMs == null) metrics.firstCompleteMs = Math.round(performance.now() - metrics.startedAt);
      purgeDisconnected();
      onChange?.(summary());
    }
  }

  function schedule() {
    if (idleHandle != null) return;
    idleHandle = typeof requestIdleCallback === 'function'
      ? requestIdleCallback(runIdle, { timeout: 500 })
      : setTimeout(() => runIdle(null), 16);
  }

  function enqueue(root) { queue.push(root); schedule(); }

  function onMutations(records) {
    for (const r of records) {
      if (isOwn(r.target)) continue;
      if (r.type === 'characterData') pending.add(r.target);
      else if (r.type === 'attributes') pending.add(r.target);
      else for (const n of r.addedNodes) pending.add(n);
      if (r.removedNodes.length) pending.add(null); // tanda perlu membersihkan
    }
    if (!pending.size) return;
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => {
      const targets = [...pending];
      pending.clear();
      if (targets.includes(null)) purgeDisconnected();
      for (const t of targets) if (t && !isOwn(t)) enqueue(t);
      if (!queue.length) onChange?.(summary());
    }, MUTATION_DEBOUNCE_MS);
  }

  function summary() {
    const byCategory = {};
    const byLevel = { selalu: 0, ketat: 0, pilihan: 0 };
    const add = (f) => {
      byCategory[f.category] = (byCategory[f.category] ?? 0) + 1;
      const t = TAXONOMY[f.category]?.tingkat;
      if (t === 'selalu') byLevel.selalu++; else if (t === 'ketat') byLevel.ketat++; else if (t === 'pilihan') byLevel.pilihan++;
    };
    for (const list of textFindings.values()) list.forEach(add);
    for (const list of fieldFindings.values()) list.forEach(add);
    return {
      url: doc.location?.href ?? '',
      total: byLevel.selalu + byLevel.ketat + byLevel.pilihan,
      byLevel, byCategory,
      textNodesWithFindings: textFindings.size,
      fieldsWithFindings: fieldFindings.size,
      metrics: { ...metrics, scanMs: Math.round(metrics.scanMs) }
    };
  }

  /** Daftar temuan untuk diagnostik; nilai disensor (hanya 2 karakter terakhir) agar tidak bocor ke console. */
  function debugList() {
    const mask = (s) => (s.length <= 2 ? '••' : `${'•'.repeat(Math.min(6, s.length - 2))}${s.slice(-2)}`);
    const rows = [];
    for (const [node, list] of textFindings) for (const f of list) {
      rows.push({ kategori: f.category, nama: TAXONOMY[f.category]?.nama, aturan: f.rule,
        elemen: node.parentElement?.tagName.toLowerCase(), nilai: mask(node.nodeValue.slice(f.start, f.end)) });
    }
    for (const [el, list] of fieldFindings) for (const f of list) {
      rows.push({ kategori: f.category, nama: TAXONOMY[f.category]?.nama, aturan: f.rule,
        elemen: `${el.tagName.toLowerCase()}[${el.name || el.id || el.type}]`, nilai: '(kolom)' });
    }
    return rows;
  }

  /** Mencari shadow root terbuka yang belum diamati (termasuk yang bersarang) lalu memindainya. */
  function sweepShadows(root) {
    const walker = doc.createTreeWalker(root, NodeFilter.SHOW_ELEMENT, {
      acceptNode: (n) => (n.hasAttribute(OWN_ATTR) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT)
    });
    for (let n = walker.nextNode(); n; n = walker.nextNode()) {
      const sr = n.shadowRoot;
      if (!sr) continue;
      if (!observedRoots.has(sr)) { observe(sr); enqueue(sr); }
      sweepShadows(sr);
    }
  }

  function start() {
    const root = doc.body ?? doc.documentElement;
    if (!root) return;
    observe(doc.documentElement);
    enqueue(root);
    sweepTimer = setInterval(() => { if (!doc.hidden && doc.documentElement) sweepShadows(doc.documentElement); }, shadowSweepMs);
  }

  function stop() {
    observers.forEach(o => o.disconnect());
    clearTimeout(debounceTimer);
    clearInterval(sweepTimer);
    if (idleHandle != null) (typeof cancelIdleCallback === 'function' ? cancelIdleCallback : clearTimeout)(idleHandle);
  }

  return { start, stop, summary, debugList, textFindings, fieldFindings };
}
