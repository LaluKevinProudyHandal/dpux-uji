/**
 * extension/background/service-worker.js
 * "Pusat komando": menyimpan status, menyalakan/mematikan mesin visi (offscreen document),
 * menjawab popup, dan mengatur badge di ikon extension.
 */

import {
  LEVEL, DEFAULT_STATE, VISION_SETTING_KEYS, PAUSE_MS, SITE_PAUSE, getState, setState, effectiveLevel, contentPayload,
  cameraNeeded, siteKey, sitePausedUntil
} from '../shared/state.js';

const OFFSCREEN_URL = 'offscreen/offscreen.html';
const ALARM_PAUSE_END = 'pause-end';
const ALARM_SITE_PREFIX = 'site-pause:'; // + origin
const ALARM_CAMERA_RETRY = 'camera-retry';
// Interval minimum chrome.alarms adalah 30 detik
const CAMERA_RETRY_MINUTES = 0.5;
// Percobaan cepat sekali setelah gagal pertama: kamera sering masih dipegang sesaat
// (mis. extension baru dimuat ulang), dan galat sesaat tidak perlu memunculkan pemberitahuan
const CAMERA_QUICK_RETRY_MS = 3000;
// Kamera sesuai kebutuhan: setelah tab aktif tidak lagi berisi data sensitif, kamera menunggu sebelum padam
// supaya tidak hidup-mati saat pengguna bolak-balik antar tab
const ALARM_CAMERA_IDLE = 'camera-idle';
const CAMERA_IDLE_MINUTES = 0.5;

// Tampilan badge per status. Warna selalu disertai teks, jadi tidak bergantung pada warna saja.
const BADGE = {
  [LEVEL.OFF]: { text: 'OFF', color: '#64748B' },
  [LEVEL.UNKNOWN]: { text: '?', color: '#64748B' },
  [LEVEL.SAFE]: { text: '', color: '#059669' },
  [LEVEL.AWARE]: { text: '•', color: '#B45309' },
  [LEVEL.THREAT]: { text: '!', color: '#DC2626' },
  [LEVEL.PAUSED]: { text: 'II', color: '#2563EB' }, // biru: abu-abu tak terlihat di toolbar (uji Kevin 18 Okt)
  [LEVEL.STANDBY]: { text: '', color: '#64748B' },   // kamera istirahat: tenang, tanpa tanda
  [LEVEL.WARMING]: { text: '…', color: '#64748B' }   // kamera bersiap; data sudah disamarkan
};

async function renderBadge() {
  const state = await getState();
  const badge = BADGE[effectiveLevel(state)];
  await chrome.action.setBadgeText({ text: badge.text });
  await chrome.action.setBadgeBackgroundColor({ color: badge.color });
  await renderSiteBadges(state);
}

/**
 * Jeda per situs: tab dari situs yang dijeda selalu menampilkan "II" biru, supaya pengguna tidak lupa
 * (risiko utama fitur ini). Tab lain kembali memakai badge umum (text: null = hapus penimpaan per tab).
 */
async function renderSiteBadges(state) {
  const tabs = await chrome.tabs.query({ url: ['http://*/*', 'https://*/*'] }).catch(() => []);
  // Warna per tab tidak bisa "dihapus" seperti teks, jadi tab yang tidak dijeda diberi warna umum lagi
  // (uji 28 Okt: setelah dilanjutkan, "!" tampil berlatar biru sisa jeda)
  const globalColor = BADGE[effectiveLevel(state)].color;
  await Promise.all(tabs.map(async (t) => {
    const paused = state.enabled && sitePausedUntil(state.sitePauses, siteKey(t.url));
    await chrome.action.setBadgeText({ tabId: t.id, text: paused ? BADGE[LEVEL.PAUSED].text : null }).catch(() => {});
    await chrome.action.setBadgeBackgroundColor({ tabId: t.id, color: paused ? BADGE[LEVEL.PAUSED].color : globalColor }).catch(() => {});
  }));
}

// ------------------------------------------------------------------ mesin visi (offscreen)

let creating = null; // mencegah createDocument dipanggil dua kali bersamaan

async function hasVisionEngine() {
  const contexts = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'] });
  return contexts.length > 0;
}

async function startVisionEngine() {
  if (await hasVisionEngine()) return;
  creating ??= chrome.offscreen.createDocument({
    url: OFFSCREEN_URL,
    reasons: ['USER_MEDIA'],
    justification: 'Mendeteksi orang lain yang menatap layar memakai webcam, diproses di perangkat.'
  }).catch((err) => {
    // Beberapa pemicu (pemasangan, popup, percobaan ulang kamera) bisa bersamaan; dokumen yang sudah ada = berhasil.
    // Temuan uji 21 Okt: penolakan ini membuat popup macet di "Memuat…".
    if (!/single offscreen/i.test(err?.message ?? '')) throw err;
  }).finally(() => { creating = null; });
  await creating;
}

async function stopVisionEngine() {
  if (await hasVisionEngine()) await chrome.offscreen.closeDocument(); // menutup halaman = kamera mati
  await setState({ level: LEVEL.UNKNOWN, stats: null, cameraActive: false, warming: false });
}

// Satu fungsi yang menyelaraskan mesin visi dengan pilihan pengguna.
// Saat dijeda kamera ikut dimatikan: pengguna tidak sedang dilindungi, jadi kamera tidak perlu menyala.
async function syncVisionEngine() {
  const { enabled, error, pausedUntil } = await getState();
  if (enabled && pausedUntil <= Date.now() && error !== 'permission') await startVisionEngine();
  else await stopVisionEngine();
  await syncCamera();
}

// ------------------------------------------------------------------ kamera sesuai kebutuhan (fondasi v1.5a)

/** Jumlah data yang akan disamarkan per tab per frame, dilaporkan content script. Disimpan selama sesi browser. */
async function getTabFindings() {
  return (await chrome.storage.session.get('tabFindings')).tabFindings ?? {};
}

async function setTabFindings(tabId, frameId, count) {
  const all = await getTabFindings();
  const tab = { ...all[tabId] };
  if (count > 0) tab[frameId] = count; else delete tab[frameId];
  if (Object.keys(tab).length) all[tabId] = tab; else delete all[tabId];
  await chrome.storage.session.set({ tabFindings: all });
}

async function forgetTab(tabId) {
  const all = await getTabFindings();
  if (!(tabId in all)) return;
  delete all[tabId];
  await chrome.storage.session.set({ tabFindings: all });
}

async function activeTabFindings() {
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (tab?.id == null) return 0;
  const frames = (await getTabFindings())[tab.id] ?? {};
  return Object.values(frames).reduce((a, b) => a + b, 0);
}

let cameraSync = Promise.resolve();

/**
 * Menyalakan kamera saat tab aktif berisi data yang akan disamarkan; memadamkannya setelah jeda bila tidak.
 * Selama kamera bersiap, status "bersiap" menyamarkan data (gagal-tertutup) tanpa pemberitahuan pojok.
 */
function syncCamera() {
  cameraSync = cameraSync.then(async () => {
    const state = await getState();
    const need = cameraNeeded(state, await activeTabFindings());
    if (need) {
      await chrome.alarms.clear(ALARM_CAMERA_IDLE);
      if (!state.cameraActive && !state.warming && !state.error) await setState({ warming: true });
      if (await hasVisionEngine()) {
        await chrome.runtime.sendMessage({ type: 'vision-set-camera', on: true }).catch(() => {});
      }
    } else if (state.cameraActive || state.warming) {
      if (!(await chrome.alarms.get(ALARM_CAMERA_IDLE))) {
        await chrome.alarms.create(ALARM_CAMERA_IDLE, { delayInMinutes: CAMERA_IDLE_MINUTES });
      }
    } else if (state.enabled && !state.error && state.level !== LEVEL.STANDBY && (await hasVisionEngine())) {
      await setState({ level: LEVEL.STANDBY, stats: null });
    }
  }).catch((err) => console.error('[service-worker] kamera', err));
  return cameraSync;
}

async function turnCameraOffIfIdle() {
  const state = await getState();
  if (cameraNeeded(state, await activeTabFindings())) return;
  await chrome.runtime.sendMessage({ type: 'vision-set-camera', on: false }).catch(() => {});
  await setState({ warming: false, level: LEVEL.STANDBY, stats: null });
}

chrome.tabs.onActivated.addListener(() => { syncCamera(); });
chrome.windows.onFocusChanged.addListener(() => { syncCamera(); });
chrome.tabs.onRemoved.addListener(async (tabId) => { await forgetTab(tabId); syncCamera(); });
chrome.tabs.onUpdated.addListener(async (tabId, info) => {
  // Halaman baru dimuat: temuan lama tidak berlaku; content script melapor ulang setelah memindai
  if (info.status === 'loading') { await forgetTab(tabId); syncCamera(); }
  // Pindah situs di tab yang sama: badge jeda per situs harus ikut berubah
  if (info.url) renderSiteBadges(await getState());
});

// ------------------------------------------------------------------ kamera tidak tersedia (C-7)

/**
 * Pemberitahuan di halaman, sekali per sesi browser, hanya bila perlindungan mati tanpa disengaja.
 * Mematikan sendiri (toggle) atau menjeda cukup terlihat di badge.
 */
async function maybeNotifyCameraIssue() {
  const state = await getState();
  if (!state.enabled || !state.error || state.cameraFallback || state.pausedUntil > Date.now()) return;
  const { cameraNoticeShown } = await chrome.storage.session.get('cameraNoticeShown');
  if (cameraNoticeShown) return;
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (tab?.id == null) return;
  // Hanya dianggap "sudah ditampilkan" bila halaman benar-benar menampilkannya;
  // tab tanpa content script (chrome://) dicoba lagi saat pengguna pindah tab.
  const shown = await chrome.tabs.sendMessage(tab.id, { type: 'dpux-camera-notice', reason: state.error }, { frameId: 0 }).catch(() => false);
  if (shown) await chrome.storage.session.set({ cameraNoticeShown: true });
}

chrome.tabs.onActivated.addListener(() => { maybeNotifyCameraIssue(); });

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name.startsWith(ALARM_SITE_PREFIX)) {
    const site = alarm.name.slice(ALARM_SITE_PREFIX.length);
    const { sitePauses } = await getState();
    const next = { ...sitePauses };
    delete next[site];
    await setState({ sitePauses: next });
    return;
  }
  if (alarm.name === ALARM_PAUSE_END) {
    await setState({ pausedUntil: 0 });
    await syncVisionEngine();
  } else if (alarm.name === ALARM_CAMERA_IDLE) {
    await turnCameraOffIfIdle();
  } else if (alarm.name === ALARM_CAMERA_RETRY) {
    // Mencoba membuka kamera lagi; berhasil → vision-ready menghapus galat dan menghentikan alarm ini
    const { enabled, error, pausedUntil } = await getState();
    if (!enabled || pausedUntil > Date.now() || error !== 'camera') {
      await chrome.alarms.clear(ALARM_CAMERA_RETRY);
      return;
    }
    await startVisionEngine();
  }
});

// ------------------------------------------------------------------ event

/**
 * Content script dari manifest hanya masuk ke tab yang dimuat SETELAH extension dipasang/diperbarui.
 * Tab yang sudah terbuka dipasangi langsung, supaya pengguna tidak perlu menekan F5 (temuan uji 21–22 Okt).
 */
async function injectIntoOpenTabs() {
  const tabs = await chrome.tabs.query({ url: ['http://*/*', 'https://*/*'] });
  await Promise.all(tabs.map(t => chrome.scripting.executeScript({
    target: { tabId: t.id, allFrames: true },
    files: ['vendor/content.js']
  }).catch(() => { /* tab yang tidak boleh disentuh (mis. Web Store) atau sedang dimuat */ })));
}

chrome.runtime.onInstalled.addListener(async ({ reason }) => {
  injectIntoOpenTabs().catch((err) => console.warn('[service-worker] pasang ke tab terbuka', err));
  if (reason === 'install') {
    await chrome.storage.local.set(DEFAULT_STATE);
    // Izin kamera harus diminta dari halaman yang terlihat, jadi buka onboarding saat pertama dipasang
    await chrome.tabs.create({ url: chrome.runtime.getURL('onboarding/onboarding.html') });
  } else {
    await setState({ level: LEVEL.UNKNOWN, stats: null, error: null, pausedUntil: 0, cameraFallback: false, cameraActive: false, warming: false });
    // Keputusan 28 Okt (pilihan A): tingkat bukan pilihan pengguna → setiap pembaruan kembali ke Standar
    const { settings } = await getState();
    if (settings?.maskMode && settings.maskMode !== 'bawaan') await setState({ settings: { ...settings, maskMode: 'bawaan' } });
    await syncVisionEngine();
  }
  await renderBadge();
});

chrome.runtime.onStartup.addListener(async () => {
  await setState({ level: LEVEL.UNKNOWN, stats: null, error: null, pausedUntil: 0, cameraFallback: false, cameraActive: false, warming: false });
  await syncVisionEngine();
  await renderBadge();
});

// Badge selalu mengikuti isi storage, siapa pun yang mengubahnya.
// ------------------------------------------------------------------ status ke halaman (T4)

let lastBroadcast = '';

/** Mengirim status ke semua tab (semua frame), hanya bila isinya berubah. */
async function broadcastToTabs() {
  const payload = contentPayload(await getState());
  const key = JSON.stringify(payload);
  if (key === lastBroadcast) return;
  lastBroadcast = key;
  // Tanpa filter URL: filter URL butuh izin "tabs"/host, tanpa izin itu hasilnya selalu kosong
  // (temuan uji Chrome 18 Okt: status tidak sampai ke tab sampai halaman dimuat ulang).
  // Tab tanpa content script (chrome://, PDF) cukup menolak pesan.
  const tabs = await chrome.tabs.query({});
  await Promise.all(tabs.map(t => chrome.tabs.sendMessage(t.id, payload).catch(() => { /* tab tanpa content script */ })));
}

// Badge dan halaman selalu mengikuti isi storage, siapa pun yang mengubahnya.
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (!['enabled', 'level', 'settings', 'pausedUntil', 'error', 'cameraFallback', 'warming', 'sitePauses'].some(k => k in changes)) return;
  renderBadge();
  broadcastToTabs();
  // Mode penyamaran / mode kamera menentukan apakah kamera perlu menyala
  if ('settings' in changes) syncCamera();
});

// Pintasan "tampilkan sementara semua" (C-6), dapat diganti di chrome://extensions/shortcuts
chrome.commands.onCommand.addListener(async (command) => {
  if (command !== 'reveal-all') return;
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab?.id != null) chrome.tabs.sendMessage(tab.id, { type: 'dpux-reveal-all' }).catch(() => {});
});

const handlers = {
  'get-state': async () => {
    // Membuka popup sekaligus memastikan mesin berjalan, tanpa membuat popup menunggu kamera menyala
    syncVisionEngine().catch((err) => console.error('[service-worker] sync', err));
    return getState();
  },
  'set-enabled': async ({ enabled }) => {
    await setState({ enabled: Boolean(enabled) });
    await syncVisionEngine();
    return getState();
  },
  // "Jeda 10 menit" (C-6); on=false melanjutkan sebelum waktunya
  // Jeda per situs (keputusan 28 Okt). duration: 'hour' | 'forever' | null (= lanjutkan)
  'set-site-pause': async ({ site, duration }) => {
    const key = siteKey(site);
    if (!key) return getState();
    const { sitePauses } = await getState();
    const next = { ...sitePauses };
    await chrome.alarms.clear(ALARM_SITE_PREFIX + key);
    if (duration === 'hour' || duration === 'forever') {
      const until = duration === 'hour' ? Date.now() + SITE_PAUSE.hour : SITE_PAUSE.forever;
      next[key] = until;
      if (duration === 'hour') await chrome.alarms.create(ALARM_SITE_PREFIX + key, { when: until });
    } else {
      delete next[key];
    }
    return setState({ sitePauses: next });
  },
  'set-pause': async ({ on }) => {
    if (on) {
      const until = Date.now() + PAUSE_MS;
      await setState({ pausedUntil: until });
      await chrome.alarms.create(ALARM_PAUSE_END, { when: until });
    } else {
      await setState({ pausedUntil: 0 });
      await chrome.alarms.clear(ALARM_PAUSE_END);
    }
    await syncVisionEngine();
    return getState();
  },
  // "Samarkan terus sampai kamera kembali" (C-7); dihapus otomatis saat kamera kembali
  'set-camera-fallback': async ({ on }) => {
    await setState({ cameraFallback: Boolean(on) });
    return getState();
  },
  'camera-granted': async () => {
    await setState({ error: null });
    await syncVisionEngine();
    return getState();
  },
  'set-settings': async ({ settings }) => {
    const { settings: current } = await getState();
    await setState({ settings: { ...current, ...settings } });
    // Mesin visi dimulai ulang hanya bila pengaturan "rem" berubah (log sesi ikut direset)
    if (VISION_SETTING_KEYS.some(k => k in settings && settings[k] !== current?.[k])) {
      if (await hasVisionEngine()) await stopVisionEngine();
      await syncVisionEngine();
    }
    return getState();
  },
  // Content script yang baru dimuat menanyakan status terkini
  'content-hello': async () => contentPayload(await getState()),
  // Jumlah data yang akan disamarkan di frame pengirim (mode terpilih) → menentukan kamera perlu menyala
  'content-findings': async ({ count }, sender) => {
    if (sender.tab?.id == null) return null;
    await setTabFindings(sender.tab.id, sender.frameId ?? 0, Number(count) || 0);
    await syncCamera();
    return true;
  },
  'vision-get-config': async () => {
    const state = await getState();
    return {
      settings: state.settings,
      cameraOn: cameraNeeded(state, await activeTabFindings()),
      extensionVersion: chrome.runtime.getManifest().version
    };
  },
  // Model siap ≠ kamera kembali. Galat kamera baru dihapus saat kamera benar-benar menyala (vision-camera).
  // Uji 28 Okt: menghapusnya di sini membuat status bolak-balik "?"/merah tiap percobaan ulang,
  // menghapus pilihan "tetap menyamarkan", dan me-reset hitungan gagal sehingga dicoba ulang tiap ±3 detik.
  'vision-ready': async () => {
    await syncCamera();
    return getState();
  },
  // Kamera menyala/padam (lampu). Saat padam, status "lensa tertutup" tidak berlaku lagi.
  'vision-camera': async ({ on }) => {
    const { error } = await getState();
    // Kamera "terbuka" belum berarti kembali: di Windows, kamera yang dipegang aplikasi lain bisa terbuka
    // tanpa gambar lalu macet (uji 28 Okt). Galat baru dihapus di vision-warm, setelah gambar benar-benar mengalir.
    if (on) return setState({ cameraActive: true });
    return setState({
      cameraActive: false, warming: false, level: LEVEL.STANDBY, stats: null,
      ...(error === 'covered' ? { error: null } : {})
    });
  },
  // Masa yakin setelah kamera menyala selesai: status kamera yang berlaku
  'vision-warm': async ({ level }) => {
    await chrome.storage.session.set({ cameraReopens: 0, cameraFailures: 0 });
    await chrome.alarms.clear(ALARM_CAMERA_RETRY);
    const { error } = await getState();
    // Kamera kembali (gambar mengalir cukup lama): galat dan pilihan "tetap menyamarkan" berakhir
    if (error === 'camera' || error === 'permission') {
      return setState({ warming: false, level, error: null, errorDetail: null, cameraFallback: false });
    }
    return setState({ warming: false, level });
  },
  // Kamera tidak bisa dibuka ulang di dokumen lama → buat ulang dokumen (model dimuat ulang, data tetap tertutup).
  // Bila terus gagal, baru dianggap kamera bermasalah (C-7).
  'vision-reopen-failed': async ({ detail }, sender) => {
    const { cameraReopens = 0 } = await chrome.storage.session.get('cameraReopens');
    if (cameraReopens >= 2) return handlers['vision-error']({ reason: 'camera', detail: `buka ulang gagal: ${detail}` }, sender);
    await chrome.storage.session.set({ cameraReopens: cameraReopens + 1 });
    console.warn('[service-worker] kamera tidak bisa dibuka ulang, dokumen kamera dibuat ulang:', detail);
    await stopVisionEngine();
    await syncVisionEngine();
    return getState();
  },
  'vision-level': async ({ level }) => setState({ level }),
  // Lensa tertutup: kamera tetap menyala (agar cepat pulih), tetapi status dinyatakan "tidak tahu" (C-7)
  'vision-covered': async ({ covered }) => {
    const { error } = await getState();
    if (covered) {
      await setState({ error: 'covered' });
      await maybeNotifyCameraIssue();
    } else if (error === 'covered') {
      await setState({ error: null, cameraFallback: false });
    }
    return getState();
  },
  'vision-stats': async ({ fps, faces, people, delegate }) => setState({ stats: { fps, faces, people, delegate } }),
  'vision-error': async ({ reason, detail }) => {
    console.warn('[service-worker] Mesin visi gagal:', reason, detail);
    await setState({ error: reason, errorDetail: detail ?? null });
    await stopVisionEngine();
    // Kamera yang sedang dipakai aplikasi lain dicoba lagi berkala.
    // Izin ditolak menunggu pengguna; galat model/internal tidak pulih sendiri.
    if (reason === 'camera') {
      const { cameraFailures = 0 } = await chrome.storage.session.get('cameraFailures');
      await chrome.storage.session.set({ cameraFailures: cameraFailures + 1 });
      if (cameraFailures === 0) {
        // Gagal pertama: coba lagi diam-diam setelah 3 detik (service worker tetap hidup selama itu)
        setTimeout(async () => {
          const { enabled, error, pausedUntil } = await getState();
          if (enabled && error === 'camera' && pausedUntil <= Date.now()) await startVisionEngine();
        }, CAMERA_QUICK_RETRY_MS);
        return getState();
      }
      await chrome.alarms.create(ALARM_CAMERA_RETRY, { periodInMinutes: CAMERA_RETRY_MINUTES });
    }
    await maybeNotifyCameraIssue();
    return getState();
  }
};

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const handler = handlers[message?.type];
  if (!handler) return false;
  handler(message, sender).then(sendResponse, (err) => {
    console.error('[service-worker]', message.type, err);
    sendResponse(null);
  });
  return true; // jawaban dikirim asinkron
});
