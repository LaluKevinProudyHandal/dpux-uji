/**
 * extension/content/main.js
 * Titik masuk content script (dibundel esbuild ke extension/vendor/content.js).
 * T2 memindai halaman, T3 menyamarkan, T4 menerima status dari service worker, T5 memberi tahu pengguna.
 */

import { createScanner } from './scanner.js';
import { createMasker } from './masker.js';
import { createNotifier } from './notice.js';
import { MASKING_LEVELS, sitePausedUntil } from '../shared/state.js';

/** Situs = origin halaman teratas (iframe ikut jeda situs induknya). */
function currentSite() {
  const ao = location.ancestorOrigins;
  return ao && ao.length ? ao[ao.length - 1] : location.origin;
}

// Waktu build bundel ini (diisi esbuild); ditampilkan di popup agar tab yang masih memakai kode lama ketahuan
const BUILD = typeof __DPUX_BUILD__ !== 'undefined' ? __DPUX_BUILD__ : 'dev';
const ORPHAN_CHECK_MS = 2000;

// Skrip ini bisa masuk dua kali ke halaman yang sama: lewat manifest dan lewat pemasangan ulang
// otomatis saat extension dipasang/diperbarui (service worker). Instans kedua tidak perlu berjalan.
if (window.__dpuxInstanceId !== chrome.runtime.id || !window.__dpuxAlive?.()) {
  start();
}

function start() {
  window.__dpuxInstanceId = chrome.runtime.id;
  window.__dpuxAlive = () => Boolean(chrome.runtime?.id);

  const isTop = window.top === window;
  let reported = false;
  let maskMode = 'bawaan';
  let pilihan = [];
  let sitePaused = false;
  let resumeTimer = null;
  let lastState = null;
  let lastFindingsCount = -1;

  /**
   * Kamera sesuai kebutuhan: melapor jumlah data yang akan disamarkan pada mode terpilih,
   * hanya saat jumlahnya berubah. Service worker menyalakan kamera bila tab aktif berisi data.
   */
  function reportFindings(summary = scanner.summary()) {
    // Situs yang dijeda melapor 0 → kamera boleh istirahat di tab ini
    const count = sitePaused ? 0 : summary.byLevel.selalu + (maskMode !== 'bawaan' ? summary.byLevel.ketat : 0)
      + pilihan.reduce((n, c) => n + (summary.byCategory[c] ?? 0), 0);
    if (count === lastFindingsCount) return;
    lastFindingsCount = count;
    chrome.runtime.sendMessage({ type: 'content-findings', count }).catch(() => { /* service worker belum siap */ });
  }

  const scanner = createScanner(document, {
    onChange(summary) {
      reportFindings(summary);
      // Ringkasan di console untuk pengujian (nilai disensor; tidak ada yang dikirim keluar)
      if (!reported && isTop) {
        reported = true;
        console.info(`[DPUX] Pindai awal selesai dalam ${summary.metrics.firstCompleteMs} ms: `
          + `${summary.byLevel.selalu} SELALU, ${summary.byLevel.ketat} KETAT`, summary.byCategory);
        const rows = scanner.debugList();
        if (rows.length) console.table(rows);
      }
    }
  });
  const masker = createMasker(document, scanner);
  // Pemberitahuan hanya di frame teratas, supaya iframe tidak memunculkan toast ganda
  const notifier = isTop ? createNotifier(document) : null;
  let lastLevel = null;

  /** Menerapkan status dari service worker: penyamaran hanya saat ada yang melihat (C3 / P3). */
  function applyState(state) {
    if (!state || state.type !== 'dpux-state') return;
    lastState = state;
    const nextPilihan = state.pilihan ?? [];
    masker.setMode(state.maskMode, nextPilihan);
    masker.setStyle(state.maskStyle);
    // Jeda per situs (keputusan 28 Okt): situs ini tidak disamarkan sampai batas waktunya
    const until = sitePausedUntil(state.sitePauses, currentSite());
    clearTimeout(resumeTimer);
    if (until && until < Number.MAX_SAFE_INTEGER) resumeTimer = setTimeout(() => applyState(lastState), until - Date.now() + 50);
    const nextPaused = Boolean(until);
    if (state.maskMode !== maskMode || nextPaused !== sitePaused || nextPilihan.join() !== pilihan.join()) {
      maskMode = state.maskMode;
      pilihan = nextPilihan;
      sitePaused = nextPaused;
      reportFindings();
    }
    // "warming" = kamera baru menyala: data ditutup dulu, tetapi tanpa toast (belum ada pengamat yang terdeteksi)
    const wasThreat = lastLevel === 'threat';
    lastLevel = sitePaused ? 'paused-site' : state.level;
    masker.setActive(!sitePaused && MASKING_LEVELS.includes(state.level));
    if (!sitePaused && state.level === 'threat' && !wasThreat) toastWhenMasked();
    // Pemberitahuan kamera hanya relevan selama status "tidak diketahui" (kamera bermasalah, belum ada pilihan).
    // Uji 28 Okt: tetap tampil setelah pengguna memilih "tetap menyamarkan" lewat popup, dan di situs yang dijeda.
    if (sitePaused || state.level !== 'unknown') notifier?.hideCameraNotice();
  }

  /**
   * T5 / C-5: toast hanya bila memang ada yang disamarkan di sekitar layar.
   * Ditunggu dua frame agar penyamar sempat menghitung penutupnya.
   */
  function toastWhenMasked() {
    if (!notifier) return;
    requestAnimationFrame(() => requestAnimationFrame(() => {
      if (masker.isActive() && masker.metrics().covers > 0) notifier.privacyToast();
    }));
  }

  /**
   * Setelah extension dimuat ulang, skrip lama kehilangan sambungan ke extension tetapi tetap hidup di halaman.
   * Ia membereskan dirinya sendiri (penutup, pemindai, pemberitahuan) agar tidak bertabrakan dengan skrip baru.
   */
  const orphanTimer = setInterval(() => {
    if (chrome.runtime?.id) return;
    clearInterval(orphanTimer);
    masker.setActive(false);
    scanner.stop();
    notifier?.hideToast();
    notifier?.hideCameraNotice();
  }, ORPHAN_CHECK_MS);

  scanner.start();
  chrome.runtime.sendMessage({ type: 'content-hello' }).then(applyState).catch(() => { /* service worker belum siap */ });

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    switch (message?.type) {
      case 'dpux-state':
        applyState(message);
        return false;
      case 'dpux-camera-notice':
        if (!notifier) return false;
        sendResponse(notifier.cameraNotice({
          reason: message.reason,
          onFallback: () => chrome.runtime.sendMessage({ type: 'set-camera-fallback', on: true }).catch(() => {})
        }));
        return false;
      case 'dpux-reveal-all':
        masker.revealAll();
        return false;
      case 'scan-summary':
        if (!isTop) return false;
        sendResponse({ ...scanner.summary(), masker: masker.metrics(), build: BUILD });
        return false;
      case 'scan-debug':
        if (!isTop) return false;
        console.table(scanner.debugList());
        sendResponse(true);
        return false;
      default:
        return false;
    }
  });
}
