/**
 * extension/dev/model-check.js
 * Membuktikan MediaPipe + vision-core bisa berjalan dari dalam extension (tanpa CDN, tanpa kamera).
 */

import { FaceLandmarker, FilesetResolver } from '../vendor/mediapipe/vision_bundle.mjs';
import { initFaceLandmarker, createVisionPipeline } from '../vendor/vision-core/index.js';

const steps = document.getElementById('steps');

function report(text, state = 'ok') {
  const li = document.createElement('li');
  li.dataset.state = state;
  li.textContent = text;
  steps.appendChild(li);
}

try {
  report('Library MediaPipe dan vision-core termuat dari folder extension');

  const t0 = performance.now();
  const landmarker = await initFaceLandmarker(FilesetResolver, FaceLandmarker, {}, {
    wasmBasePath: chrome.runtime.getURL('vendor/mediapipe/wasm'),
    modelAssetPath: chrome.runtime.getURL('vendor/mediapipe/face_landmarker.task')
  });
  report(`Model siap dalam ${Math.round(performance.now() - t0)} ms, memakai ${landmarker.delegate}`);

  // Gambar kosong 640×480: seharusnya 0 wajah, dan pipeline melaporkan "safe"
  const canvas = new OffscreenCanvas(640, 480);
  canvas.getContext('2d').fillRect(0, 0, 640, 480);
  const result = landmarker.detectForVideo(canvas, performance.now());
  const out = createVisionPipeline().process(result.faceLandmarks, 640, 480, performance.now());
  report(`Deteksi uji: ${result.faceLandmarks.length} wajah, status pipeline "${out.level}"`);

  report('Semua berhasil. Langkah 2 selesai.');
} catch (err) {
  console.error(err);
  report(`Gagal: ${err.message}`, 'fail');
}
