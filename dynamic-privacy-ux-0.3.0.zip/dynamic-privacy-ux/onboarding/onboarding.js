/**
 * extension/onboarding/onboarding.js
 * Tiga langkah (keputusan G1, 23 Okt): izinkan kamera → sematkan ikon → lihat contoh (bisa dilewati).
 * Izin kamera berlaku untuk seluruh origin extension, termasuk offscreen document.
 */

import { MODE_DESCRIPTION } from '../popup/view.js';

const card = document.getElementById('card');
const statusEl = document.getElementById('status');
const btnAllow = document.getElementById('btn-allow');
const btnDone = document.getElementById('btn-done');
const help = document.getElementById('help');
const preview = document.getElementById('preview');
const video = document.getElementById('video');
const pinStep = document.getElementById('pin-step');
const pinStatus = document.getElementById('pin-status');
const demoStep = document.getElementById('demo-step');
const demo = document.getElementById('demo');
const demoToast = document.getElementById('demo-toast');
const btnDemo = document.getElementById('btn-demo');
const DEMO_MS = 5000;

/** Menandai langkah: 'done' | 'current' | '' */
function setProgress(step, state) {
  const el = document.getElementById(`prog-${step}`);
  if (state) el.dataset.state = state; else delete el.dataset.state;
}

let stream = null;

function stopPreview() {
  stream?.getTracks().forEach(t => t.stop());
  stream = null;
  video.srcObject = null;
  preview.hidden = true;
}

function showGranted(withPreview) {
  card.dataset.state = 'granted';
  chrome.runtime.sendMessage({ type: 'camera-granted' }).catch(() => {});
  statusEl.textContent = withPreview
    ? 'Kamera diizinkan. Ini yang dilihat kamera; gambar tidak disimpan ke mana pun.'
    : 'Kamera sudah diizinkan. Perlindungan siap dipakai.';
  btnAllow.hidden = true;
  help.hidden = true;
  setProgress(1, 'done');
  if (demoStep.hidden) setProgress(2, 'current');
  showPinStep();
}

// ------------------------------------------------------------------ C-9: sematkan ikon

let pinTimer = null;

/** Langkah wajib setelah izin kamera; status sematan dicek berkala karena Chrome tidak memberi event. */
function showPinStep() {
  pinStep.hidden = false;
  if (pinTimer) return;
  const check = async () => {
    const settings = await chrome.action.getUserSettings?.().catch(() => null);
    if (!settings) return;
    pinStep.dataset.state = settings.isOnToolbar ? 'pinned' : 'idle';
    pinStatus.textContent = settings.isOnToolbar
      ? 'Ikon sudah disematkan. Perlindungan siap dipakai.'
      : 'Ikon belum disematkan.';
  };
  check();
  pinTimer = setInterval(check, 1000);
}

function showDenied() {
  card.dataset.state = 'denied';
  statusEl.textContent = 'Kamera belum diizinkan.';
  btnAllow.disabled = false;
  btnAllow.textContent = 'Coba lagi';
  help.hidden = false;
}

btnAllow.addEventListener('click', async () => {
  btnAllow.disabled = true;
  statusEl.textContent = 'Menunggu izin dari Anda…';
  try {
    stream = await navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 480 }, audio: false });
    video.srcObject = stream;
    preview.hidden = false;
    showGranted(true);
  } catch (err) {
    console.warn('[onboarding] Izin kamera gagal:', err);
    showDenied();
  }
});

btnDone.addEventListener('click', async () => {
  stopPreview();
  const tab = await chrome.tabs.getCurrent();
  if (tab?.id) chrome.tabs.remove(tab.id);
});

window.addEventListener('pagehide', stopPreview);

// ------------------------------------------------------------------ langkah 3: contoh (tanpa kamera)

document.getElementById('mode-bawaan').textContent = MODE_DESCRIPTION.bawaan;

document.getElementById('btn-pin-next').addEventListener('click', () => {
  stopPreview();
  setProgress(2, 'done');
  setProgress(3, 'current');
  demoStep.hidden = false;
  demoStep.scrollIntoView({ behavior: 'smooth', block: 'start' });
});

/** Meniru apa yang terjadi saat ada orang menghadap layar: data fiktif disamarkan selama 5 detik. */
btnDemo.addEventListener('click', () => {
  const secrets = [...demo.querySelectorAll('.secret')];
  secrets.forEach(el => { el.dataset.real = el.textContent; el.textContent = el.dataset.mask; });
  demo.classList.add('masked');
  demoToast.hidden = false;
  btnDemo.disabled = true;
  setTimeout(() => {
    secrets.forEach(el => { el.textContent = el.dataset.real; });
    demo.classList.remove('masked');
    demoToast.hidden = true;
    btnDemo.disabled = false;
    btnDemo.textContent = 'Lihat lagi';
  }, DEMO_MS);
});

document.getElementById('btn-finish').addEventListener('click', async () => {
  setProgress(3, 'done');
  const tab = await chrome.tabs.getCurrent();
  if (tab?.id) chrome.tabs.remove(tab.id);
});

// Tampilkan status izin yang sudah ada, dan ikuti perubahannya
// (mis. pengguna mengubah izin lewat pengaturan situs tanpa memuat ulang halaman)
const permission = await navigator.permissions.query({ name: 'camera' });

function syncWithPermission() {
  if (permission.state === 'granted') showGranted(Boolean(stream));
  else if (permission.state === 'denied') { stopPreview(); showDenied(); }
}

permission.addEventListener('change', syncWithPermission);
syncWithPermission();
